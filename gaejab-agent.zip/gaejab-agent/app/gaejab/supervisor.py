"""컨트롤 센터: 수집기 프로세스를 켜고 끄고 지켜봄(죽으면 다시 켬, 업데이트되면 다시 켬)."""
import logging
import os
import subprocess
import sys
import threading
import time

from . import config, status

log = logging.getLogger("gaejab")
RUN_PY = str(config.BASE / "run.py")
IS_WIN = os.name == "nt"


# ── 프로세스 도우미 ───────────────────────────────────
def pid_alive(pid):
    if not pid:
        return False
    if IS_WIN:
        import ctypes
        k = ctypes.windll.kernel32
        k.OpenProcess.restype = ctypes.c_void_p
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        k.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        h = k.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        k.GetExitCodeProcess(h, ctypes.byref(code))
        k.CloseHandle(h)
        return code.value == 259  # STILL_ACTIVE
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False


def read_pid(path):
    try:
        return int(path.read_text().strip())
    except Exception:
        return None


def kill_tree(pid):
    if not pid:
        return
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True,
                           creationflags=0x08000000)  # CREATE_NO_WINDOW
        else:
            import signal
            try:
                os.killpg(os.getpgid(int(pid)), signal.SIGTERM)
            except Exception:
                os.kill(int(pid), signal.SIGTERM)
    except Exception as e:
        log.warning("강제 종료 실패: %s", e)


def spawn(args, role=None):
    """창 없이 독립 프로세스로 실행."""
    env = dict(os.environ)
    if role is not None:
        env["GAEJAB_ROLE"] = role
    if IS_WIN:
        exe = sys.executable
        pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(pyw):
            exe = pyw
        return subprocess.Popen([exe, RUN_PY] + args, cwd=str(config.BASE),
                                creationflags=0x00000008 | 0x00000200 | 0x08000000, env=env,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
    return subprocess.Popen([sys.executable, RUN_PY] + args, cwd=str(config.BASE), start_new_session=True, env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)


# ── 수집기 관리 ───────────────────────────────────────
def free_gb():
    try:
        from .sysinfo import _mem
        return _mem()["avail_gb"]
    except Exception:
        return 99.0


class _CpuMeter:
    """호출 사이의 전체 CPU 사용률(%)을 기다림 없이 계산."""

    def __init__(self):
        self.prev = None

    def sample(self):
        if not IS_WIN:
            return None
        import ctypes
        FT = ctypes.c_ulonglong
        i, k, u = FT(), FT(), FT()
        ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(i), ctypes.byref(k), ctypes.byref(u))
        cur = (i.value, k.value, u.value)
        prev, self.prev = self.prev, cur
        if not prev:
            return None
        idle, tot = cur[0] - prev[0], (cur[1] - prev[1]) + (cur[2] - prev[2])
        return round(100 * (1 - idle / tot), 1) if tot else None


class Supervisor:
    """역할별 수집기를 켜고 지켜봄 + 메모리·CPU 상황에 따라 수집 브라우저 수를 자동 조절."""

    def __init__(self):
        self.procs = {}
        self.lock = threading.Lock()
        self.started_at = None
        self.restarts = 0
        self.stopping = False
        self.target = None          # 지금 목표로 하는 브라우저 수
        self.last_scale = 0.0
        self.low_since = self.high_since = self.hot_since = None
        self.cpu = _CpuMeter()
        self.last_cpu = None
        self.last_free = None

    def role_pid(self, role):
        pr = self.procs.get(role)
        if pr and pr.poll() is None:
            return pr.pid
        pid = read_pid(config.pid_path(role))
        return pid if pid_alive(pid) else None

    def crawler_pid(self):
        for r in config.CRAWLER_ROLES:
            pid = self.role_pid(r)
            if pid:
                return pid
        return None

    def running(self):
        return self.crawler_pid() is not None

    def _init_target(self):
        if self.target is not None:
            return
        alive = max([i + 1 for i, r in enumerate(config.CRAWLER_ROLES) if self.role_pid(r)] or [0])   # 이미 돌고 있는 것 이어받기
        base = config.BASE_BROWSERS if free_gb() >= 2.0 else config.MIN_BROWSERS
        self.target = max(config.MIN_BROWSERS, min(config.MAX_BROWSERS, len(config.CRAWLER_ROLES), max(base, alive)))
        log.info("수집 브라우저 %d개로 시작 (여유 메모리 %.1fGB)", self.target, free_gb())

    def active_roles(self):
        self._init_target()
        return config.CRAWLER_ROLES[:self.target]

    def _set_stop_roles(self, add=(), remove=()):
        cur = set(status.read_control().get("stop_roles") or [])
        new = (cur | set(add)) - set(remove)
        if new != cur:
            status.write_control(stop_roles=sorted(new))

    def _start_missing(self, reason):
        started = False
        for role in self.active_roles():
            if self.role_pid(role):
                continue
            self._set_stop_roles(remove=[role])
            self.procs[role] = spawn(["--crawler"], role)
            started = True
            log.info("수집기 시작 (%s · %s) pid=%s", reason, role or "단독", self.procs[role].pid)
        if started:
            self.started_at = self.started_at or time.time()
        return started

    def _stop_role(self, role, reason):
        """브라우저 하나만 끔(정상 종료 요청 → 늦으면 강제 종료)."""
        pid = self.role_pid(role)
        self._set_stop_roles(add=[role])
        log.info("수집기 끔 (%s · %s)", reason, role)

        def wait():
            t0 = time.time()
            while time.time() - t0 < config.STOP_GRACE_SEC and self.role_pid(role):
                time.sleep(0.5)
            if pid and self.role_pid(role):
                kill_tree(pid)
            try:
                config.pid_path(role).unlink()
            except Exception:
                pass
        threading.Thread(target=wait, daemon=True).start()

    def autoscale(self):
        """여유 메모리·CPU를 보고 브라우저 수를 1개씩 늘리거나 줄임."""
        self._init_target()
        now = time.time()
        f = free_gb()
        c = self.cpu.sample()
        self.last_free, self.last_cpu = f, c
        self.low_since = (self.low_since or now) if f < config.SCALE_DOWN_FREE_GB else None
        self.hot_since = (self.hot_since or now) if (c is not None and c > 90) else None
        can_up = f >= config.SCALE_UP_FREE_GB and (c is None or c < config.SCALE_CPU_MAX)
        self.high_since = (self.high_since or now) if can_up else None
        n_max = min(config.MAX_BROWSERS, len(config.CRAWLER_ROLES))
        stopping = set(status.read_control().get("stop_roles") or [])
        for role in config.CRAWLER_ROLES[self.target:]:   # 목표보다 많이 떠 있는 브라우저 정리
            if role not in stopping and self.role_pid(role):
                self._stop_role(role, "목표 개수 초과")
        down = (self.low_since and now - self.low_since > 40) or (self.hot_since and now - self.hot_since > 60)
        if down and self.target > config.MIN_BROWSERS and now - self.last_scale > 60:
            self.target -= 1
            self.last_scale = now
            self.low_since = self.hot_since = None
            role = config.CRAWLER_ROLES[self.target]
            msg = f"메모리 부족(여유 {f:.1f}GB, CPU {c or 0:.0f}%) → 수집 브라우저 {self.target + 1}→{self.target}개"
            log.info(msg)
            status.event(msg, "warn")
            self._stop_role(role, "자동 조절")
        elif (self.high_since and now - self.high_since > 120 and self.target < n_max
              and now - self.last_scale > config.SCALE_COOLDOWN_MIN * 60):
            self.target += 1
            self.last_scale = now
            self.high_since = None
            msg = f"여유 있음(여유 {f:.1f}GB, CPU {c or 0:.0f}%) → 수집 브라우저 {self.target - 1}→{self.target}개"
            log.info(msg)
            status.event(msg)
            self._start_missing("자동 조절")

    def start(self, reason="시작 버튼"):
        with self.lock:
            fresh = not self.running()
            status.write_control(want_running=True, stop=False, stop_roles=[],
                                 **({"paused": False} if fresh else {}))
            return self._start_missing(reason)

    def stop(self, reason="종료 버튼"):
        """정상 종료 요청 → 시간 안에 안 꺼지면 강제 종료(크롬 포함)."""
        with self.lock:
            self.stopping = True
            status.write_control(want_running=False, stop=True)
        try:
            pids = {r: self.role_pid(r) for r in config.CRAWLER_ROLES}
            if not any(pids.values()):
                return
            log.info("수집기 종료 요청 (%s)", reason)
            t0 = time.time()
            while time.time() - t0 < config.STOP_GRACE_SEC and self.running():
                time.sleep(0.5)
            for r, pid in pids.items():
                if pid and self.role_pid(r):
                    log.info("정상 종료가 늦어 강제 종료 (%s)", r or "단독")
                    kill_tree(pid)
                try:
                    config.pid_path(r).unlink()
                except Exception:
                    pass
            self.started_at = None
            status.update(state="stopped", action="수집기 꺼짐 (시작 버튼으로 다시 켤 수 있음)")
        finally:
            self.stopping = False

    def reset_data(self):
        """수집 데이터 전체 삭제(캡처·리포트·DB) 후 수집을 처음부터 다시 시작. 크롬 프로필은 유지."""
        import shutil
        from . import db
        was_running = self.running() or status.read_control().get("want_running")
        log.info("데이터 초기화 시작")
        self.stop(reason="데이터 초기화")
        for d in (config.CAPTURES, config.REPORTS, config.DATA / "diag", config.DATA / "export", config.DATA / "tmp"):
            shutil.rmtree(d, ignore_errors=True)
        for f in [config.LIVE_PATH, config.STATUS_PATH, config.DATA / "gaejab.pid"] + \
                [config.DATA / f"{n}{config.role_suffix(r)}.{e}" for r in config.SLOT_ROLES[1:]
                 for n, e in (("status", "json"), ("live", "jpg"))]:
            try:
                os.remove(f)
            except Exception:
                pass
        conn = db.connect()
        conn.executescript("DELETE FROM sightings; DELETE FROM frames; DELETE FROM ads;"
                           "INSERT INTO ads_fts(ads_fts) VALUES('rebuild');")
        conn.commit()
        conn.execute("VACUUM")
        conn.close()
        config.ensure_dirs()
        from . import publisher
        publisher.reset_state()
        status.write_control(reset=False)
        log.info("데이터 초기화 완료")
        if was_running:
            self.start(reason="초기화 후 재시작")

    def watch(self):
        """5초마다 확인: 켜져 있어야 하는데 꺼져 있으면 다시 켬(오류·업데이트 재시작)."""
        def loop():
            while True:
                time.sleep(5)
                try:
                    ctl = status.read_control()
                    if ctl.get("reset"):
                        self.reset_data()
                        continue
                    want = ctl.get("want_running")
                    if want and not self.stopping:
                        with self.lock:
                            if not ctl.get("paused"):
                                self.autoscale()
                            if self._start_missing("자동 재시작"):
                                self.restarts += 1
                except Exception:
                    log.exception("감시 오류")
        threading.Thread(target=loop, daemon=True).start()

    def info(self):
        pid = self.crawler_pid()
        ctl = status.read_control()
        roles = {(r or "단독"): self.role_pid(r) for r in config.CRAWLER_ROLES}
        return {"running": pid is not None, "pid": pid, "roles": roles, "browsers": self.target,
                "browsers_alive": sum(1 for v in roles.values() if v), "free_gb": self.last_free, "cpu": self.last_cpu, "want_running": bool(ctl.get("want_running")),
                "paused": bool(ctl.get("paused")), "autostart": autostart_enabled(),
                "autostart_supported": IS_WIN, "restarts": self.restarts}


# ── 윈도우 시작 시 자동 실행 ──────────────────────────
def _startup_file():
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    return os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup", "gaejab_autostart.bat")


def autostart_enabled():
    f = _startup_file() if IS_WIN else None
    return bool(f and os.path.exists(f))


def set_autostart(on):
    """PC를 켜면 컨트롤 센터가 자동으로 뜨고, 수집이 켜져 있던 상태면 수집도 이어서 시작."""
    f = _startup_file() if IS_WIN else None
    if not f:
        return False
    if on:
        exe = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        if not os.path.exists(exe):
            exe = sys.executable
        body = ('@echo off\r\ncd /d "%s"\r\nstart "" "%s" "%s" --no-open\r\n'
                % (str(config.BASE), exe, RUN_PY))
        with open(f, "w", encoding="mbcs") as fh:   # 한글 경로를 윈도우 명령창이 읽을 수 있게
            fh.write(body)
    else:
        try:
            os.remove(f)
        except FileNotFoundError:
            pass
    return True

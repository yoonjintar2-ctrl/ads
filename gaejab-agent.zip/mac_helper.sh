#!/bin/bash
# 게재나라 보조 수집기 (맥북용) — 운영자 본인의 맥에서 실행. 캡처는 윈도우 중앙 PC로 모입니다.
# 사용법: 터미널에서  bash mac_helper.sh   (처음 한 번은 설치까지 1~3분)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$HOME/Library/Application Support/GaejaeNara"
mkdir -p "$ROOT"
rsync -a --delete "$HERE/app/" "$ROOT/app/"
if [ ! -x "$ROOT/venv/bin/python" ]; then
  python3 -m venv "$ROOT/venv"
  "$ROOT/venv/bin/pip" install -q --upgrade pip
  "$ROOT/venv/bin/pip" install -q "playwright==1.48.0" pillow
fi
export GAEJAB_DATA="$ROOT/data"
cd "$ROOT/app"
exec "$ROOT/venv/bin/python" agent.py --helper

"""게잡머신 실행 진입점.

  python run.py              컨트롤 센터(대시보드: 시작·종료·현황·데이터). 이미 떠 있으면 대시보드만 열어줌
  python run.py --start      컨트롤 센터 + 수집 바로 시작
  python run.py --stop-all   수집기와 컨트롤 센터 모두 종료
  python run.py --crawler    수집기 본체(컨트롤 센터가 알아서 실행하므로 직접 쓸 일 없음)
"""
import argparse
import asyncio
import json
import logging
import logging.handlers
import os
import sys
import threading
import time
import urllib.request
import webbrowser

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gaejab import config, db, report, status  # noqa: E402

URL = f"http://localhost:{config.DASHBOARD_PORT}"


def setup_logging(filename):
    config.ensure_dirs()
    h = logging.handlers.RotatingFileHandler(config.DATA / filename, maxBytes=5_000_000, backupCount=3,
                                             encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    root = logging.getLogger("gaejab")
    root.setLevel(logging.INFO)
    root.addHandler(h)
    if sys.stdout:
        root.addHandler(logging.StreamHandler(sys.stdout))


def snapshot(files):
    out = {}
    for p in files:
        try:
            out[str(p)] = p.stat().st_mtime
        except Exception:
            pass
    return out


# ════════════════════ 수집기 ════════════════════
CRAWLER_FILES = lambda: [config.BASE / "run.py"] + sorted((config.BASE / "gaejab").glob("*.py"))  # noqa: E731
EXIT = {"why": ""}


async def report_loop():
    """10분마다 오늘 리포트 갱신, 날짜가 바뀌면 전날 리포트 확정."""
    last_day = db.today()
    while True:
        await asyncio.sleep(600)
        try:
            conn = db.connect()
            d = db.today()
            if d != last_day:
                report.write_day(conn, last_day)
                status.event(f"{last_day} 일별 리포트 저장 완료")
                last_day = d
            report.write_day(conn, d)
            conn.close()
        except Exception:
            logging.getLogger("gaejab").exception("리포트 저장 오류")


def _hard_exit_later(sec=15):
    """정리 작업이 멈춰도 확실히 끝나도록 안전장치."""
    def bye():
        try:
            if EXIT["why"] == "update":
                status.update(state="starting", action="업데이트 적용 중… 곧 다시 시작합니다")
            else:
                status.update(state="stopped", action="수집기 꺼짐 (시작 버튼으로 다시 켤 수 있음)")
            if read_pid(config.PID_PATH) == os.getpid():
                config.PID_PATH.unlink()
        finally:
            os._exit(0)
    t = threading.Timer(sec, bye)
    t.daemon = True
    t.start()


async def watch_exit(main_task):
    """종료 버튼(stop 신호)이나 프로그램 업데이트를 감지하면 깔끔하게 종료."""
    base = snapshot(CRAWLER_FILES())
    n = 0
    while True:
        await asyncio.sleep(2)
        n += 1
        if status.stop_requested():
            EXIT["why"] = "stop"
            status.event("종료 요청 → 수집기를 끕니다")
            _hard_exit_later()
            main_task.cancel()
            return
        if n % 8 == 0:
            cur = snapshot(CRAWLER_FILES())
            if cur != base:
                await asyncio.sleep(5)  # 파일 복사가 끝날 시간
                changed = sorted({os.path.basename(k) for k in cur if cur.get(k) != base.get(k)})
                EXIT["why"] = "update"
                status.event(f"프로그램 업데이트 감지({', '.join(changed)}) → 수집기 재시작")
                _hard_exit_later()
                main_task.cancel()
                return


async def crawl():
    from playwright.async_api import async_playwright
    from gaejab.browser import launch, LiveView, Shooter
    from gaejab.youtube import YouTubeCrawler

    log = logging.getLogger("gaejab")
    asyncio.create_task(report_loop())
    asyncio.create_task(watch_exit(asyncio.current_task()))
    backoff = 10
    while True:
        shooter = Shooter()
        live = LiveView(shooter)
        try:
            async with async_playwright() as pw:
                ctx = await launch(pw)
                live.start()
                crawler = YouTubeCrawler(ctx, live, shooter)
                backoff = 10
                try:
                    if await crawler.run_forever() == "recycle":
                        EXIT["why"] = "update"     # 수집기를 통째로 다시 띄움(파이썬·크롬 메모리 초기화) → 컨트롤 센터가 곧 다시 켬
                        _hard_exit_later(20)
                        return
                finally:
                    try:
                        await ctx.close()
                    except Exception:
                        pass
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.exception("브라우저 오류 — 재시작")
            status.update(state="error", action=f"브라우저 재시작 중… ({str(e)[:80]})")
            status.event(f"브라우저가 닫혀 {backoff}초 후 재시작: {str(e)[:120]}", "error")
        finally:
            live.stop()
        await asyncio.sleep(backoff)
        backoff = min(backoff * 2, 300)


def _low_priority():
    """참여자 PC: 수집기와 수집용 크롬을 '낮음' 우선순위로 → 사용자 작업이 항상 먼저."""
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000)  # BELOW_NORMAL
        except Exception:
            pass


def run_crawler():
    if config.AGENT:
        _low_priority()   # 여기서 띄우는 크롬도 같은 낮은 우선순위를 물려받음
    setup_logging(f"gaejab{config.role_suffix(config.ROLE)}.log")
    config.PID_PATH.write_text(str(os.getpid()))
    status.write_control(stop=False)
    status.update(state="starting", action="크롬 실행 중…")
    import signal

    def _term(*_):
        raise KeyboardInterrupt
    try:
        signal.signal(signal.SIGTERM, _term)
    except Exception:
        pass
    try:
        asyncio.run(crawl())
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    finally:
        if EXIT["why"] == "update":
            status.update(state="starting", action="업데이트 적용 중… 곧 다시 시작합니다")
        else:
            status.update(state="stopped", action="수집기 꺼짐 (시작 버튼으로 다시 켤 수 있음)")
        try:
            if read_pid(config.PID_PATH) == os.getpid():
                config.PID_PATH.unlink()
        except Exception:
            pass


def read_pid(path):
    try:
        return int(path.read_text().strip())
    except Exception:
        return None


# ════════════════════ 컨트롤 센터 ════════════════════
CONTROLLER_FILES = lambda: [config.BASE / "run.py"] + [config.BASE / "gaejab" / f for f in (  # noqa: E731
    "dashboard.py", "supervisor.py", "status.py", "db.py", "report.py", "config.py", "publisher.py", "sysinfo.py", "datamove.py", "cloudsync.py")]


def post(action):
    req = urllib.request.Request(URL + "/api/control", data=json.dumps({"action": action}).encode(),
                                 headers={"Content-Type": "application/json"}, method="POST")
    return urllib.request.urlopen(req, timeout=5).read()


def controller_alive():
    try:
        urllib.request.urlopen(URL + "/api/ping", timeout=2).read()
        return True
    except Exception:
        return False


def run_controller(a):
    from gaejab import dashboard
    from gaejab.supervisor import Supervisor, spawn

    if controller_alive():   # 이미 떠 있으면 대시보드만 열기
        if a.start:
            try:
                post("start")
            except Exception:
                pass
        if not a.no_open:
            webbrowser.open(URL)
        return

    from gaejab import datamove
    if datamove.move_if_pending():   # 데이터 폴더를 새 위치(D드라이브 등)로 옮겼으면 새 위치로 다시 시작
        spawn(["--no-open"])
        return

    setup_logging("controller.log")
    log = logging.getLogger("gaejab")
    log.info("데이터 폴더: %s", config.DATA)
    conn = db.connect()
    try:
        db.migrate(conn)
    except Exception:
        log.exception("데이터 보정 실패")
    conn.close()

    sup = Supervisor()
    dashboard.SUP = sup
    srv = None
    for _ in range(20):  # 재시작 직후에는 이전 프로세스가 포트를 놓을 때까지 잠시 대기
        try:
            srv = dashboard.serve(block=False)
            break
        except OSError:
            time.sleep(1)
    if srv is None:
        print(f"대시보드 포트 {config.DASHBOARD_PORT}를 쓸 수 없습니다.")
        return
    config.CONTROLLER_PID_PATH.write_text(str(os.getpid()))
    log.info("컨트롤 센터 시작: %s", URL)

    if a.start or (status.read_control().get("want_running") and not sup.running()):
        sup.start(reason="실행 시 자동 시작" if not a.start else "시작 파일")
    sup.watch()
    from gaejab import publisher
    publisher.start(sup)   # 공개 현황 사이트 자동 갱신
    try:
        from gaejab import sysinfo
        sysinfo.start()    # PC 사양·부하 기록(data/sysinfo.json)
        datamove.compact_in_background(log)   # 기존 캡처 용량 줄이기(한 번만)
        from gaejab import cloudsync
        cloudsync.start()                      # 참여자 게재면 접수·포인트 원본 요청 처리(서버 주소가 설정됐을 때만)
    except Exception:
        log.exception("사양 측정 시작 실패")
    if not a.no_open and config.OPEN_DASHBOARD_ON_START:
        webbrowser.open(URL)

    # 컨트롤 센터 자체가 업데이트되면 스스로 다시 띄움(수집기는 그대로 계속 돎)
    base = snapshot(CONTROLLER_FILES())
    try:
        while True:
            time.sleep(10)
            if snapshot(CONTROLLER_FILES()) != base:
                time.sleep(4)
                log.info("컨트롤 센터 업데이트 → 재시작")
                srv.shutdown()
                srv.server_close()
                spawn(["--no-open"])
                os._exit(0)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            if read_pid(config.CONTROLLER_PID_PATH) == os.getpid():
                config.CONTROLLER_PID_PATH.unlink()
        except Exception:
            pass


def stop_all():
    from gaejab.supervisor import Supervisor, kill_tree, pid_alive
    setup_logging("controller.log")
    Supervisor().stop(reason="종료 파일")
    cpid = read_pid(config.CONTROLLER_PID_PATH)
    if cpid and pid_alive(cpid) and cpid != os.getpid():
        kill_tree(cpid)
    print("게잡머신을 모두 종료했습니다.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--crawler", action="store_true", help="수집기 본체 실행")
    ap.add_argument("--start", action="store_true", help="컨트롤 센터 + 수집 바로 시작")
    ap.add_argument("--stop-all", action="store_true", help="모두 종료")
    ap.add_argument("--dashboard", action="store_true", help="(예전 옵션) 컨트롤 센터와 같음")
    ap.add_argument("--no-open", action="store_true", help="대시보드를 자동으로 열지 않음")
    a = ap.parse_args()
    if a.crawler:
        run_crawler()
    elif a.stop_all:
        stop_all()
    else:
        run_controller(a)


if __name__ == "__main__":
    main()

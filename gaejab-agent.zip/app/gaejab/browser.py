"""크롬 실행(로그아웃 전용 프로필) + 캡처(브라우저 창 전체/페이지) + 대시보드용 라이브 화면."""
import asyncio
import time
import logging
import os
import uuid

from . import config, status, wincap

log = logging.getLogger("gaejab")

BASE_ARGS = [
    # 창이 가려지거나 화면 밖에 있어도 영상·타이머·화면 그리기가 멈추지 않게
    "--disable-backgrounding-occluded-windows",
    "--disable-renderer-backgrounding",
    "--disable-background-timer-throttling",
    "--disable-features=Translate,MediaRouter,OptimizationHints,CalculateNativeWinOcclusion",
    "--autoplay-policy=no-user-gesture-required",
    # 게재보고 화면에 불필요한 알림·말풍선이 뜨지 않게
    "--no-first-run",
    "--no-default-browser-check",
    "--hide-crash-restore-bubble",
    "--disable-session-crashed-bubble",
    "--lang=ko-KR",
    f"--disk-cache-size={config.CHROME_DISK_CACHE_MB * 1024 * 1024}",
]


def window_capture_wanted():
    return config.CAPTURE_MODE == "window" and wincap.AVAILABLE and config.WINDOW_MODE != "headless"


async def launch(pw):
    """개인 크롬과 완전히 분리된 전용 프로필(북마크·로그인·확장프로그램 없음)로 실행."""
    config.ensure_dirs()
    args = list(BASE_ARGS)
    if config.MUTE:
        args.append("--mute-audio")
    headless = config.WINDOW_MODE == "headless"
    kw = dict(user_data_dir=str(config.PROFILE_DIR), headless=headless, locale="ko-KR",
              timezone_id="Asia/Seoul", bypass_csp=True, args=args,
              chromium_sandbox=(os.name == "nt"),   # '지원되지 않는 명령줄 플래그(--no-sandbox)' 경고줄이 캡처에 안 나오게
              ignore_default_args=["--enable-automation"])   # '자동화 소프트웨어로 제어 중' 알림 숨김
    if window_capture_wanted():
        w, h = config.WINDOW_SIZE
        x, y = wincap.offscreen_xy() if config.WINDOW_MODE == "offscreen" else (0, 0)
        args += [f"--window-size={w},{h}", f"--window-position={x},{y}"]   # 켜질 때부터 화면 밖
        if config.FORCE_SCALE:
            args.append(f"--force-device-scale-factor={config.FORCE_SCALE}")
        kw["no_viewport"] = True     # 페이지가 실제 창 크기를 그대로 씀(창 캡처와 일치)
    else:
        kw["viewport"] = config.VIEWPORT
        kw["screen"] = config.VIEWPORT
        if not headless:
            args += ["--window-size=560,380", "--window-position=30,60"]
    if config.BROWSER_CHANNEL:
        try:
            ctx = await pw.chromium.launch_persistent_context(channel=config.BROWSER_CHANNEL, **kw)
            log.info("구글 크롬으로 실행")
            return ctx
        except Exception as e:
            log.warning("구글 크롬 실행 실패 → 내장 Chromium으로 대체: %s", e)
    return await pw.chromium.launch_persistent_context(**kw)


class Shooter:
    """게재보고용 캡처. 윈도우에서는 탭·주소창까지 보이는 실제 크롬 창 전체를 찍음."""

    def __init__(self):
        self.hwnd = None
        self.window_ok = window_capture_wanted()
        self._warned = False
        self.cdp = {}   # 모바일 탭 → CDP 세션(폰 실제 해상도로 캡처)
        self.shorts_hires = False  # 쇼츠 고해상도 캡처는 재생이 멈춰 컷이 빠지는 문제로 끔(인스트림만 고해상도)
        self.shorts_fail = 0

    async def locate(self, page):
        """제목에 표시를 달아 수집용 크롬 창을 찾고, 정해진 위치(화면 밖 등)로 옮김."""
        if not self.window_ok:
            return False
        marker = "GAEJAB-" + uuid.uuid4().hex[:8]
        try:
            old = await page.evaluate("(m) => { const o = document.title; document.title = m; return o; }", marker)
            hwnd = None
            for _ in range(20):
                await asyncio.sleep(0.25)
                hwnd = await asyncio.to_thread(wincap.find_window, marker)
                if hwnd:
                    break
            await page.evaluate("(o) => { document.title = o; }", old)
        except Exception as e:
            log.warning("크롬 창 찾기 실패: %s", e)
            hwnd = None
        if not hwnd:
            self._fallback("수집용 크롬 창을 찾지 못함")
            return False
        self.hwnd = hwnd
        await asyncio.to_thread(wincap.place, hwnd, config.WINDOW_MODE, config.WINDOW_SIZE)
        log.info("수집용 크롬 창 확보 (%s 배치)", config.WINDOW_MODE)
        return True

    def _fallback(self, why):
        self.window_ok = False
        if not self._warned:
            self._warned = True
            status.event(f"브라우저 창 캡처 불가({why}) → 페이지 화면만 캡처합니다", "warn")

    async def shot(self, page, path, quality=None, clip=None, window=True, hires=True):
        """window=True면 창 전체, 아니면(모바일 등) 페이지 화면."""
        q = quality or config.JPEG_QUALITY
        if window and self.window_ok and clip is None:
            if not wincap.is_window(self.hwnd):
                await self.locate(page)
            if self.window_ok:
                try:
                    await page.bring_to_front()
                except Exception:
                    pass
                # 창을 옮기거나 숨긴 직후 3초는 화면이 덜 그려져 뒤 화면이 비칠 수 있어 잠깐 기다림
                wait = 3.0 - (time.time() - wincap.LAST_PLACE.get("t", 0)) if hasattr(wincap, "LAST_PLACE") else 0
                if wait > 0:
                    await asyncio.sleep(wait)
                ok = await asyncio.to_thread(wincap.capture, self.hwnd, str(path), q)
                if ok and not _blank(path):
                    return
                self._fallback("창 캡처 결과가 비어 있음")
        # 쇼츠는 고해상도 캡처를 하면 재생이 멈춰서(1~2컷만 저장됨) 일반 캡처 사용
        cdp = self.cdp.get(id(page)) if (clip is None and hires) else None
        if cdp is not None:
            try:   # 폰 실제 해상도로 찍음. 3초 안에 안 끝나면(영상이 멈추는 원인) 이 탭은 일반 캡처로 전환
                import base64
                # 보이는 화면 영역을 배율 1로 지정해서 찍음(폰 실제 해상도). 배율을 소수로 주면 바둑판처럼 깨졌고,
                # 영역 없이 찍으면 쇼츠 재생이 멈췄음 → 깨짐은 아래에서 자동 확인 후 다시 찍음
                vp = await page.evaluate("() => [innerWidth, innerHeight]")
                r = await asyncio.wait_for(cdp.send("Page.captureScreenshot", {
                    "format": "jpeg", "quality": 92, "captureBeyondViewport": False,
                    "clip": {"x": 0, "y": 0, "width": vp[0], "height": vp[1], "scale": 1}}), 3)
                with open(str(path), "wb") as f:
                    f.write(base64.b64decode(r["data"]))
                await asyncio.to_thread(shrink_portrait, str(path), q, True)
                if not await asyncio.to_thread(looks_tiled, str(path)):
                    return
                log.warning("모바일 캡처가 깨져(반복 무늬) 일반 캡처로 다시 찍음")
            except Exception as e:
                self.cdp.pop(id(page), None)
                log.warning("모바일 고해상도 캡처 실패(%s) → 이 탭은 일반 캡처로 전환", type(e).__name__)
        await page.screenshot(path=str(path), type="jpeg", quality=q, clip=clip, timeout=10000)
        await asyncio.to_thread(shrink_portrait, str(path), q)


def looks_tiled(path):
    """화면이 가로로 반복된(바둑판처럼 깨진) 캡처인지 확인: 가로로 밀었을 때 자기 자신과 거의 같으면 깨진 것."""
    try:
        from PIL import Image, ImageChops, ImageStat
        with Image.open(path) as im:
            g = im.convert("L").resize((200, 440))
        best = 255.0
        for sh in range(40, 140, 2):
            a = g.crop((sh, 0, 200, 440))
            b = g.crop((0, 0, 200 - sh, 440))
            best = min(best, ImageStat.Stat(ImageChops.difference(a, b)).mean[0])
        return best < 8
    except Exception:
        return False


def shrink_portrait(path, quality=None, force_save=False):
    """세로형(모바일) 캡처가 너무 크면 가로 PORTRAIT_MAX_W로 줄여 다시 저장."""
    try:
        from PIL import Image
        with Image.open(path) as im:
            w, h = im.size
            if h <= w or w <= config.PORTRAIT_MAX_W:
                if force_save:
                    im.convert("RGB").save(path + ".tmp.jpg", "JPEG", quality=quality or config.JPEG_QUALITY, optimize=True)
                if force_save:
                    os.replace(path + ".tmp.jpg", path)
                return False
            nh = int(h * config.PORTRAIT_MAX_W / w)
            small = im.convert("RGB").resize((config.PORTRAIT_MAX_W, nh), Image.LANCZOS)
        small.save(path, "JPEG", quality=quality or config.JPEG_QUALITY, optimize=True)
        return True
    except Exception:
        return False


def _blank(path):
    from .imaging import is_mostly_blank
    return is_mostly_blank(path)


class LiveView:
    """몇 초마다 현재 화면을 data/live.jpg로 저장 → 대시보드에서 실시간으로 보임."""

    def __init__(self, shooter=None):
        self.page = None
        self.shooter = shooter
        self.window = True
        self._task = None
        self.hold = False   # 캡처 중에는 잠시 멈춤(캡처 타이밍 방해 방지)

    def start(self):
        self._task = asyncio.create_task(self._loop())

    async def _loop(self):
        tmp = str(config.LIVE_PATH) + ".tmp.jpg"
        n = 0
        while True:
            await asyncio.sleep(config.LIVE_VIEW_INTERVAL_SEC)
            n += 1
            # 10번(약 30초)마다: 모니터 연결 등으로 창이 화면 안으로 끌려왔으면 다시 숨김
            if n % 10 == 0 and self.shooter and self.shooter.hwnd and config.WINDOW_MODE == "offscreen":
                try:
                    h = self.shooter.hwnd
                    if await asyncio.to_thread(wincap.on_screen, h) or \
                            (wincap.HIDE_TASKBAR and await asyncio.to_thread(wincap.in_taskbar, h)):
                        await asyncio.to_thread(wincap.place, h, config.WINDOW_MODE, config.WINDOW_SIZE)
                        log.info("수집용 크롬 창이 화면에 나와 있어 다시 숨김")
                except Exception:
                    pass
            if self.hold or not self.page or self.page.is_closed():
                continue
            try:
                if self.shooter and self.window and self.shooter.window_ok:
                    ok = await asyncio.to_thread(wincap.capture, self.shooter.hwnd, tmp, 55)
                    if not ok:
                        continue
                else:
                    await self.page.screenshot(path=tmp, type="jpeg", quality=55, timeout=5000)
                os.replace(tmp, config.LIVE_PATH)
            except Exception:
                pass

    async def push(self, src_path):
        """캡처한 컷을 라이브 화면에도 바로 반영."""
        try:
            import shutil
            shutil.copyfile(src_path, str(config.LIVE_PATH) + ".tmp2.jpg")
            os.replace(str(config.LIVE_PATH) + ".tmp2.jpg", config.LIVE_PATH)
        except Exception:
            pass

    def stop(self):
        if self._task:
            self._task.cancel()

"""게잡머신 설정 — 이 파일의 값만 바꿔도 동작을 조정할 수 있습니다."""
import os
from pathlib import Path

# ── 경로 ─────────────────────────────────────────────
BASE = Path(__file__).resolve().parent.parent
OLD_DATA = BASE / "data"
LOCATION_FILE = BASE / "data_location.txt"   # 여기에 적힌 폴더(예: D:\게재나라\data)로 데이터 저장 위치를 옮김
MOVED_MARK = ".gaejab_data_ok"


def _data_dir():
    env = os.environ.get("GAEJAB_DATA")
    if env:
        return Path(env)
    try:
        t = Path(LOCATION_FILE.read_text(encoding="utf-8-sig").strip())
        if (t / MOVED_MARK).exists():
            return t
    except Exception:
        pass
    return OLD_DATA


def pending_move_target():
    """data_location.txt에 새 위치가 적혀 있는데 아직 옮기지 않았으면 그 경로."""
    if os.environ.get("GAEJAB_DATA"):
        return None
    try:
        t = Path(LOCATION_FILE.read_text(encoding="utf-8-sig").strip())
    except Exception:
        return None
    if not str(t) or (t / MOVED_MARK).exists():
        return None
    return t


DATA = _data_dir()
CAPTURES = DATA / "captures"          # 날짜/지면/광고ID/01.jpg … 08.jpg
REPORTS = DATA / "reports"            # 일별 리포트 HTML·CSV
DB_PATH = DATA / "gaejab.db"          # 색인 DB (SQLite)
# 수집 브라우저 여러 개 동시 운용 — 메모리 상황에 따라 개수를 자동으로 늘리고 줄임(상황이 좋을수록 많이)
# 수집기마다 역할(ROLE)이 있고, 아래 순서대로 켜고(늘릴 때) 뒤에서부터 끔(줄일 때)
#  pc      = PC 인스트림 + PC 인피드          mobile  = 모바일 인스트림 + 인피드 + 쇼츠
#  pc2/pc3 = PC 인스트림 전담(가장 중요)       mobile2 = 모바일 인스트림 전담
SLOT_ROLES = ["pc", "mobile", "pc2", "mobile2", "pc3"]
MULTI_BROWSER = True
MIN_BROWSERS = 1                 # 메모리가 아무리 부족해도 이 개수는 유지
MAX_BROWSERS = 5
BASE_BROWSERS = 2                # 시작할 때 기본 개수(메모리가 되면)
SCALE_UP_FREE_GB = 3.6           # 여유 메모리가 이 이상으로 2분간 유지되면 1개 추가
SCALE_DOWN_FREE_GB = 1.1         # 여유 메모리가 이 아래로 40초간 떨어지면 1개 줄임
SCALE_CPU_MAX = 80               # CPU 사용률이 이 이상이면 늘리지 않음(90% 넘게 1분 지속되면 1개 줄임)
SCALE_COOLDOWN_MIN = 5           # 개수를 바꾼 뒤 이 시간 동안은 다시 바꾸지 않음(메모리 안정 대기)
# 참여자 컴퓨터용 수집기(설치형)인지: 브라우저는 최대 2개, 메모리 여유가 넉넉할 때만 2개
AGENT = os.environ.get("GAEJAB_AGENT") == "1"
# 보조 수집기(운영자 본인의 다른 컴퓨터, 예: 맥북): 참여자 수집기와 같은 경로로 중앙 PC에 보내되, 브라우저를 여러 개 씀
HELPER = AGENT and os.environ.get("GAEJAB_HELPER") == "1"
if HELPER:
    SLOT_ROLES = ["pc", "mobile", "pc2"]
    MAX_BROWSERS, BASE_BROWSERS, MIN_BROWSERS = 3, 2, 1
    AGENT_YIELD_CPU = 95          # 보조 수집기는 거의 쉬지 않음(정말 버거울 때만)
    AGENT_YIELD_FREE_GB = 0.8
    AGENT_RESUME_CPU = 70
elif AGENT:
    # 참여자 PC는 '조용히, 가볍게': 브라우저 1개만, 낮은 우선순위, 쉬는 시간 넉넉히, 바쁘면 알아서 쉼
    SLOT_ROLES = ["pc"]
    MAX_BROWSERS, BASE_BROWSERS, MIN_BROWSERS = 1, 1, 1
    AGENT_YIELD_CPU = 60          # 참여자 PC의 CPU 사용률이 이 이상으로 1분 넘게 가면 수집을 잠시 쉼
    AGENT_YIELD_FREE_GB = 2.0     # 여유 메모리가 이보다 적어도 쉼
    AGENT_RESUME_CPU = 40         # CPU가 이 아래, 여유 메모리 3GB 이상으로 2분 지나면 다시 수집
CRAWLER_ROLES = SLOT_ROLES if MULTI_BROWSER else [""]
MIN_FREE_GB_FOR_SECOND = 2.0     # (예전 설정 호환)
ROLE = os.environ.get("GAEJAB_ROLE", "")


def role_suffix(role):
    if role in ("", "pc"):
        return ""
    return "_m" if role == "mobile" else "_" + role


_SFX = role_suffix(ROLE)
STATUS_PATH = DATA / f"status{_SFX}.json"    # 대시보드가 읽는 진행 상황
LIVE_PATH = DATA / f"live{_SFX}.jpg"         # 지금 크롬이 보고 있는 화면
CONTROL_PATH = DATA / "control.json"  # 일시정지/재개 신호
LOG_PATH = DATA / "gaejab.log"
PID_PATH = DATA / f"crawler{_SFX}.pid"        # 수집기 프로세스


def pid_path(role):
    return DATA / f"crawler{role_suffix(role)}.pid"

CONTROLLER_PID_PATH = DATA / "controller.pid"   # 컨트롤 센터(대시보드) 프로세스
PROFILE_DIR = DATA / f"chrome_profile_youtube{_SFX}"   # 로그아웃 전용 크롬 프로필 (개인 크롬과 분리)

# ── 대시보드 ─────────────────────────────────────────
DASHBOARD_PORT = int(os.environ.get("GAEJAB_PORT", 8765))
OPEN_DASHBOARD_ON_START = True
STOP_GRACE_SEC = 25             # 종료 버튼 → 이 시간 안에 안 꺼지면 강제 종료
LIVE_VIEW_INTERVAL_SEC = 3

# ── 브라우저 ─────────────────────────────────────────
# "chrome" = PC에 설치된 구글 크롬 사용(권장, 영상 코덱 지원이 완전함)
# None     = Playwright 내장 Chromium 사용
BROWSER_CHANNEL = os.environ.get("GAEJAB_CHANNEL", "chrome") or None
# 게재보고 캡처 방식
#  "window" : 주소창·탭까지 보이는 실제 크롬 창 전체를 캡처(윈도우 PC 전용). 실패하면 자동으로 "page"
#  "page"   : 웹페이지 화면만 캡처
CAPTURE_MODE = os.environ.get("GAEJAB_CAPTURE", "window")
# 수집용 크롬 창 위치
#  "offscreen" : 화면 밖에 띄워서 작업 중인 화면을 가리지 않음(캡처는 정상)
#  "visible"   : 화면에 보이게 띄움(동작을 직접 보고 싶을 때)
#  "headless"  : 창 없이 실행(창 캡처 불가 → 페이지 캡처)
WINDOW_MODE = os.environ.get("GAEJAB_WINDOW", "offscreen")
WINDOW_SIZE = (1920, 1200)      # 수집용 크롬 창 크기(게재보고 캡처 크기). 영상 아래 제목까지 보이도록 세로를 넉넉히
# 윈도우 화면 배율(125%·150%)과 상관없이 100% 배율로 그림 → 화면이 덜 확대돼 영상 제목·채널명까지 한 화면에 들어옴
FORCE_SCALE = 1.0
MUTE = True                     # 소리 끄기(광고 송출에는 영향 없음)
VIEWPORT = {"width": 1920, "height": 1080}   # "page" 캡처일 때 화면 크기

# ── 광고 캡처 ────────────────────────────────────────
FRAMES_PER_AD = 8
# 광고 길이 대비 캡처 지점(비율). 8개
FRAME_POINTS = [0.03, 0.12, 0.25, 0.38, 0.52, 0.66, 0.80, 0.93]
MAX_AD_WATCH_SEC = 90           # 긴 광고는 앞 90초 안에서 8컷을 나눠 찍고 건너뜀
# True면 플레이어만 화면 가득 키워서 캡처. 게재보고는 브라우저 화면 전체가 필요하므로 기본은 False
YT_FULLSCREEN = False
JPEG_QUALITY = 90              # 게재보고용 화질 우선(D드라이브 여유 충분)
PORTRAIT_MAX_W = 1080           # 세로형(모바일) 캡처 최대 폭
PORTRAIT_SHOT_W = 828           # 모바일 캡처 폭(아이폰 일반 모델 화면 폭 수준, 412px보다 2배 선명)
CHROME_DISK_CACHE_MB = 200      # 수집용 크롬 캐시 상한

# ── 랜딩 URL ─────────────────────────────────────────
# "always"   : 처음 보는 광고는 1회 클릭해 최종 랜딩 URL + 랜딩 페이지 캡처(게재 증빙)
# "fallback" : 광고 데이터에서 랜딩 URL을 못 찾을 때만 클릭
# "never"    : 클릭하지 않음(광고 데이터에 적힌 URL만 저장)
CLICK_MODE = "always"
LANDING_TIMEOUT_SEC = 20

# ── 중복 판정 ────────────────────────────────────────
DHASH_MAX_DISTANCE = 6          # 광고 ID를 못 얻었을 때 이미지 유사도 기준(0~64, 작을수록 엄격)
RECAPTURE_AFTER_DAYS = 0        # 0 = 같은 광고는 평생 1회만 캡처. 30 = 30일 이상 안 보이다 재등장하면 재캡처

# ── 탐색 패턴 ─────────────────────────────────────────
# 프리롤만 수집: 영상에 들어가서 이 시간 안에 광고가 안 뜨면 다음 영상으로
PREROLL_WAIT_SEC = (5, 7)        # 프리롤은 대부분 3초 안에 뜸(모바일은 광고 준비 신호가 있으면 자동 연장)
AFTER_AD_WATCH_SEC = (2, 4)     # 광고가 끝난 뒤 본편을 잠깐 보고 이동(연속 광고 확인 겸)
VIDEOS_PER_ROUND = (3, 4)       # 검색 1번에 영상 여러 개를 이어서 봄(추천 영상으로 이동) → 검색 페이지 로딩 절약
PC_VIDEOS_PER_ROUND = (8, 10)   # PC는 인스트림(프리롤)이 최우선 → 영상을 더 많이 봄
PC_INFEED_SCAN_RATE = 0.08      # PC 인피드는 페이지 12번 중 1번꼴로만 확인(인스트림에 시간 집중)
SHORTS_PER_ROUND = (12, 25)     # 쇼츠 1라운드에 넘겨볼 개수
SHORTS_WATCH_SEC = (3, 8)       # 쇼츠 1개당 시청 시간
# 라운드 순서(반복)
#  pc      = PC 인스트림(프리롤) + PC 인피드(검색 결과·추천 목록 광고)
#  mobile  = 모바일 인스트림(프리롤) + 모바일 인피드
#  mshorts = 모바일 쇼츠
#  shorts  = PC 쇼츠(현재 수집 대상 아님)
ROUND_ORDER = {"pc": ["pc"], "pc2": ["pc"], "pc3": ["pc"], "mobile": ["mobile", "mshorts"],
               "mobile2": ["mobile"]}.get(ROLE, ["pc", "mobile", "mshorts"])
INSTREAM_ONLY = ROLE in ("pc2", "pc3")   # 추가 PC 브라우저는 인스트림(프리롤)만. 모바일은 인피드가 귀해서 모든 모바일 브라우저가 확인
MOBILE_ENABLED = True
PAUSE_BETWEEN_SEC = (3, 10)
RECYCLE_EVERY_MIN = 60          # 오래 켜 둔 크롬은 메모리가 계속 불어나서, 이 시간마다 수집기·크롬을 새로 띄움(라운드 사이에)
CLEAR_COOKIES_EVERY_HOURS = 6   # 시청 기록이 쌓여 추천이 한쪽으로 쏠리지 않게 주기적으로 초기화
BOT_CHECK_COOLDOWN_MIN = 30     # '로봇이 아닙니다' 확인 화면이 뜨면 쉬는 시간
# 가동 시간대(24시간제). None = 24시간. 예: (7, 24) → 오전 7시~자정
ACTIVE_HOURS = None

# 모바일 인피드(검색 결과 광고)는 광고주가 검색어에 입찰해야 붙어서, 모바일 검색의 절반은 업종별 '구매·상담 의도' 검색어를 씀
# (업종은 장르와 똑같이 고르게 돌림 — 특정 업종 쏠림 없음)
COMMERCIAL_KW = {
    "뉴스·시사": ["신문 구독", "경제지 구독"], "예능": ["OTT 추천", "넷플릭스 요금제"], "드라마·영화": ["영화 예매", "OTT 할인"],
    "음악": ["음원 스트리밍 요금", "블루투스 이어폰 추천"], "게임": ["모바일 게임 추천", "게임 사전예약"],
    "뷰티·패션": ["선크림 추천", "탈모 샴푸", "남자 정장"], "자동차": ["신차 견적", "자동차 보험 비교", "장기렌트"],
    "IT·테크": ["노트북 추천", "알뜰폰 요금제", "무선 청소기 추천"], "재테크·금융": ["주택담보대출 금리", "신용카드 추천", "실손보험"],
    "요리·먹방": ["밀키트 추천", "배달 할인"], "육아·키즈": ["유아 학습지", "분유 추천", "어린이 보험"],
    "스포츠": ["헬스장 등록", "골프채 추천", "러닝화 추천"], "여행": ["항공권 특가", "호텔 예약", "제주 렌터카"],
    "생활·건강": ["영양제 추천", "정수기 렌탈", "치과 임플란트"], "교육·자기계발": ["영어회화 학원", "자격증 인강", "코딩 부트캠프"],
    "쇼핑·리빙": ["매트리스 추천", "소파 추천"], "반려동물": ["강아지 사료 추천", "펫보험"], "커리어·비즈니스": ["이직 사이트", "프랜차이즈 창업"],
    "부동산·인테리어": ["아파트 분양", "인테리어 견적"], "시니어·건강": ["보청기 가격", "실버보험"],
}
MOBILE_COMMERCIAL_RATE = 0.5
MOBILE_HOME_SCAN_RATE = 0.35     # 모바일 라운드 뒤 홈 피드도 훑어 인피드 광고 확인하는 비율
# 장르별 검색어 — 자유롭게 추가/수정
# 장르별 검색어 — 업종을 가리지 않고 골고루 보도록 넓게 구성(장르는 섞어서 차례로 돌고, 다 돌면 다시 섞음)
GENRES = {
    "뉴스·시사": ["오늘 뉴스", "경제 뉴스", "날씨 예보", "국제 뉴스", "정치 뉴스", "사건사고"],
    "예능": ["예능 하이라이트", "웃긴 영상 모음", "토크쇼 클립", "연애 예능", "관찰 예능", "웹예능"],
    "드라마·영화": ["드라마 명장면", "영화 리뷰", "영화 예고편", "드라마 요약", "넷플릭스 추천", "애니메이션"],
    "음악": ["케이팝 무대", "뮤직비디오", "플레이리스트 카페", "라이브 클립", "트로트", "힙합"],
    "게임": ["게임 공략", "롤 하이라이트", "모바일 게임 리뷰", "스팀 신작", "마인크래프트", "배그"],
    "뷰티·패션": ["메이크업 튜토리얼", "데일리룩", "스킨케어 루틴", "올리브영 추천", "향수 추천", "헤어스타일"],
    "자동차": ["신차 리뷰", "전기차 시승기", "중고차 추천", "자동차 비교", "수입차", "오토바이"],
    "IT·테크": ["스마트폰 리뷰", "노트북 추천", "언박싱", "애플 신제품", "AI 활용법", "가전 추천"],
    "재테크·금융": ["주식 시황", "부동산 전망", "재테크 방법", "미국 주식", "보험 추천", "카드 혜택", "대출 금리"],
    "요리·먹방": ["레시피", "먹방", "맛집 추천", "자취 요리", "편의점 신상", "카페 디저트"],
    "육아·키즈": ["육아 꿀팁", "아기 동요", "키즈 장난감", "이유식 만들기", "초등 공부", "임신 출산"],
    "스포츠": ["축구 하이라이트", "야구 하이라이트", "홈트레이닝", "골프 레슨", "러닝", "농구"],
    "여행": ["여행 브이로그", "일본 여행", "국내 여행지 추천", "캠핑", "호텔 리뷰", "항공권 특가"],
    "생활·건강": ["건강 정보", "청소 꿀팁", "인테리어", "다이어트 식단", "영양제 추천", "수면"],
    "교육·자기계발": ["영어 공부", "자격증 공부", "공무원 시험", "독서 리뷰", "자기계발", "코딩 강의"],
    "쇼핑·리빙": ["쇼핑 하울", "가구 추천", "생활용품 추천", "가성비 템", "명품 언박싱", "살림 꿀팁"],
    "반려동물": ["강아지 영상", "고양이 영상", "반려동물 용품", "강아지 훈련"],
    "커리어·비즈니스": ["직장인 브이로그", "창업 아이템", "취업 면접", "마케팅 전략", "부업"],
    "부동산·인테리어": ["아파트 분양", "집 꾸미기", "이사 꿀팁", "전세 월세"],
    "시니어·건강": ["노후 준비", "건강 체조", "트로트 메들리", "시니어 정보"],
}

# ── 공개 현황 사이트 (ads.jintar.co.kr) ─────────────────
SITE_REPO = "yoonjintar2-ctrl/ads"          # GitHub Pages 저장소
SITE_BRANCH = "main"
SITE_DOMAIN = "ads.jintar.co.kr"
GITHUB_TOKEN_PATH = DATA / "github_token.txt"   # 이 파일에만 키 보관(없으면 사이트 갱신 안 함)
SITE_PUBLISH_MIN = 3                        # 몇 분마다 사이트 갱신
SITE_MAX_ADS = 150                          # 사이트에 고화질로 보여줄 최근 광고 수(나머지는 저화질 썸네일 + PC에서 원본 불러오기)
SITE_MAX_NEW_IMAGES = 150                   # 한 번에 올릴 새 이미지 수(나머지는 다음 회차)
# 사이트 피드백(로그인 없이): 사이트 → ntfy.sh 공개 알림 채널 → PC가 5분마다 받아서 data/feedback.json에 보관
FEEDBACK_TOPIC = "gaejab-fb-0e6815c847ac"
# 사이트에서 오래된 광고의 고화질 원본을 요청하는 채널(PC가 8초마다 확인 → 해당 광고 컷을 사이트에 올림)
ONDEMAND_TOPIC = "gaejab-od-493ef92c7cd1"
SITE_PLACEMENTS = ["youtube_instream", "youtube_infeed", "youtube_mobile_instream",
                   "youtube_mobile_infeed", "youtube_mobile_shorts"]

# 테스트용(실서비스에서는 건드리지 않음)
YT_BASE = os.environ.get("GAEJAB_YT_BASE", "https://www.youtube.com")
YT_MOBILE_BASE = os.environ.get("GAEJAB_YT_MOBILE_BASE",
                                "https://m.youtube.com" if "www.youtube.com" in YT_BASE else YT_BASE)
# 모바일 에뮬레이션(갤럭시 S23 크롬)
MOBILE_UA = ("Mozilla/5.0 (Linux; Android 14; SM-S911N) AppleWebKit/537.36 (KHTML, like Gecko) "
             "Chrome/141.0.0.0 Mobile Safari/537.36")
MOBILE_SCREEN = {"width": 412, "height": 915, "scale": 2.625}


def ensure_dirs():
    for p in (DATA, CAPTURES, REPORTS, PROFILE_DIR):
        p.mkdir(parents=True, exist_ok=True)


if AGENT and not HELPER:
    PAUSE_BETWEEN_SEC = (15, 40)    # 라운드 사이에 넉넉히 쉼
    PC_VIDEOS_PER_ROUND = (3, 4)
    RECYCLE_EVERY_MIN = 45
    CHROME_DISK_CACHE_MB = 100

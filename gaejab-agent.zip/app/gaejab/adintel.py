"""광고 데이터에서 광고 ID·랜딩 URL·광고 문구를 뽑아내는 도우미.

유튜브는 광고를 띄울 때 플레이어 데이터(JSON)에 광고 영상 ID와 클릭 URL(adurl=최종 랜딩)을 함께 내려줍니다.
네트워크 응답을 엿들어 'ID → 랜딩 URL/문구' 표를 만들어 두고, 광고가 화면에 뜨면 이 표에서 찾습니다.
"""
import json
import re
import time
from urllib.parse import urlparse, parse_qs, unquote

AD_NODE_RE = re.compile(
    r"(instreamVideoAd|linearAdSequence|adSlot|adPlacement|playerOverlayLayout|instreamAdPlayerOverlay|"
    r"AdLayout|adLayout|reelPlayerOverlay|shortsAd|inFeedAd|adBreak|playerAds|adPlacements|"
    r"AdRenderer|adVideoId|adInfo|promotedVideo|compactPromoted)", re.I)
CLICK_URL_RE = re.compile(r"(adurl=|googleadservices\.com|doubleclick\.net|/pagead/aclk|/aclk\?)", re.I)
VID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
TEXT_KEYS = ("simpleText", "text", "content", "headline", "description", "title", "label",
             "advertiserName", "channelName", "displayName")
WATCH_URL_PARTS = ("/youtubei/v1/player", "/youtubei/v1/next", "get_midroll_info",
                   "/youtubei/v1/reel", "/youtubei/v1/browse", "/youtubei/v1/get_ad")

NOISE_LINES = re.compile(
    r"^(스폰서|광고|Sponsored|Ad|광고 ·|·|건너뛰기|광고 건너뛰기|Skip|Skip Ad|Skip ads|\d+|"
    r"\d{1,2}:\d{2}(\s*/\s*\d{1,2}:\d{2})?|광고\s*\d.*|Ad\s*\d.*|.*초 후 .*|.*후 동영상 재생|"
    r"광고주 페이지 방문.*|Visit advertiser.*|내 광고 센터|My Ad Center|정보|Info|공유|Share|좋아요|싫어요|댓글|구독|Subscribe|더보기|"
    r"\d+(\.\d+)?(천|만|K|M)?|\d+\s*/\s*\d+|광고\s*\d+\s*/\s*\d+)$", re.I)
# 쇼츠 화면의 버튼 설명 문구(광고와 무관)
UI_NOISE = re.compile(r"(좋아요 표시|싫어요 표시|댓글을 사용할 수 없|댓글 \d|공유|리믹스|이 동영상|다른 사용자|"
                      r"구독자|조회수|liked this|like this video|Comments are turned off)", re.I)
# 접근성용 꼬리말(화면에는 안 보임) 제거
A11Y_TAIL = re.compile(r"\s*(This link opens in (a )?new tab|새 탭에서 열림|새 창에서 열림|링크가 새 탭에서 열립니다)\.?$", re.I)
CTA_RE = re.compile(r"(자세히|알아보기|설치|구매|구입|신청|방문|예약|다운로드|바로가기|쇼핑|주문|"
                    r"보러 가기|사이트|앱 열기|Learn more|Install|Shop|Buy|Sign up|Visit|Download|Book|Get)", re.I)
DOMAIN_RE = re.compile(r"\b((?:[a-z0-9-]+\.)+(?:com|co\.kr|kr|net|org|io|shop|store|app|me|tv|ai))\b", re.I)


def declared_from_click(url):
    """구글 광고 클릭 URL에서 adurl(광고주가 설정한 랜딩) 파라미터를 꺼냄. 못 꺼내면 빈 값."""
    try:
        qs = parse_qs(urlparse(url).query)
        for k in ("adurl", "url", "q"):
            if k in qs and qs[k][0].startswith("http"):
                return unquote(qs[k][0])
    except Exception:
        pass
    return "" if CLICK_URL_RE.search(url or "") else url


def _walk(o, out, in_ad=False, depth=0):
    """하위 트리에서 (광고ID들, 클릭URL들, 문구들)을 모아 반환하고, 광고 노드마다 out에 기록."""
    ids, urls, texts = set(), set(), []
    if depth > 60:
        return ids, urls, texts
    if isinstance(o, dict):
        for k, v in o.items():
            child_ad = in_ad or bool(AD_NODE_RE.search(k))
            if isinstance(v, str):
                if k in ("externalVideoId", "adVideoId") and VID_RE.match(v):
                    ids.add(v)
                elif k == "videoId" and in_ad and VID_RE.match(v):
                    ids.add(v)
                elif v.startswith("http") and CLICK_URL_RE.search(v):
                    urls.add(v)
                elif k in TEXT_KEYS and in_ad and 1 < len(v) <= 120:
                    texts.append(v)
                if k == "playerVars" and "video_id=" in v:
                    m = re.search(r"video_id=([A-Za-z0-9_-]{11})", v)
                    if m:
                        ids.add(m.group(1))
            else:
                i2, u2, t2 = _walk(v, out, child_ad, depth + 1)
                ids |= i2
                urls |= u2
                texts += t2
                if AD_NODE_RE.search(k) and (i2 or u2):
                    out.append({"ids": set(i2), "urls": set(u2), "texts": list(dict.fromkeys(t2))[:40]})
    elif isinstance(o, list):
        for v in o:
            i2, u2, t2 = _walk(v, out, in_ad, depth + 1)
            ids |= i2
            urls |= u2
            texts += t2
    return ids, urls, texts


class AdIntel:
    """네트워크로 받은 광고 데이터 저장소."""

    def __init__(self):
        self.by_id = {}        # 광고영상ID → {"urls": set, "texts": list, "ts": float}
        self.recent = []       # ID 없이 들어온 광고 데이터(최근 것)

    def ingest(self, data):
        nodes = []
        try:
            _walk(data, nodes)
        except RecursionError:
            return
        now = time.time()
        # 클릭 URL에 들어 있는 video_id(광고 영상 ID)로도 묶어 둠
        for n in nodes:
            for u in list(n["urls"]):
                m = re.search(r"[?&]video_id=([A-Za-z0-9_-]{11})", u)
                if m:
                    n["ids"].add(m.group(1))
        for n in nodes:
            if n["ids"]:
                for vid in n["ids"]:
                    e = self.by_id.setdefault(vid, {"urls": set(), "texts": [], "ts": now})
                    e["urls"] |= n["urls"]
                    e["texts"] = list(dict.fromkeys(e["texts"] + n["texts"]))[:60]
                    e["ts"] = now
            elif n["urls"]:
                self.recent.append({"urls": n["urls"], "texts": n["texts"], "ts": now})
        self.recent = [r for r in self.recent if now - r["ts"] < 180][-20:]
        if len(self.by_id) > 500:
            for k in sorted(self.by_id, key=lambda k: self.by_id[k]["ts"])[:200]:
                self.by_id.pop(k, None)

    def ingest_text(self, text):
        text = text.strip()
        if not text or text[0] not in "{[":
            # midroll 응답 등은 앞에 )]}' 가 붙기도 함
            i = text.find("{")
            if i < 0:
                return
            text = text[i:]
        try:
            self.ingest(json.loads(text))
        except Exception:
            pass

    async def on_response(self, resp):
        try:
            u = resp.url
            if not any(p in u for p in WATCH_URL_PARTS):
                return
            ct = (resp.headers or {}).get("content-type", "")
            if "json" not in ct and "text" not in ct:
                return
            self.ingest_text(await resp.text())
        except Exception:
            pass

    def lookup(self, vid):
        """광고 ID로 (광고주가 설정한 랜딩 URL, 클릭 URL, 문구 목록) 찾기."""
        # 광고 ID로 확실히 짝지어진 데이터만 씀(다른 광고의 URL이 섞이는 것 방지)
        e = self.by_id.get(vid) if vid else None
        if not e:
            return "", "", []
        own = [u for u in e["urls"] if f"video_id={vid}" in u]   # 이 광고 ID가 직접 박힌 URL 우선
        urls = sorted(own or e["urls"], key=lambda u: ("adurl=" not in u, len(u)))
        click = urls[0] if urls else ""
        return (declared_from_click(click) if click else ""), click, e["texts"]


# ── 화면 텍스트 → 광고주/제목/CTA 추정 ─────────────────
def clean_lines(text):
    out = []
    pieces = []
    for ln in (text or "").replace("\r", "").split("\n"):
        pieces += re.split(r"\s+[·•|]\s+", ln)
    for ln in pieces:
        ln = A11Y_TAIL.sub("", ln).strip(" ·•|\t")
        if not ln or len(ln) > 160 or NOISE_LINES.match(ln) or UI_NOISE.search(ln):
            continue
        if ln not in out:
            out.append(ln)
    return out


def guess_fields(lines, hints=(), vd_title="", vd_author="", landing_url="", is_ad_vid=False):
    advertiser, title, cta = "", "", ""
    if is_ad_vid:
        title = vd_title or ""
        advertiser = vd_author or ""
    cands = [l for l in list(lines) + list(hints) if l]
    for l in cands:
        if not cta and CTA_RE.search(l) and len(l) <= 20:
            cta = l
    if not advertiser:
        for l in cands:
            m = DOMAIN_RE.search(l)
            if m:
                advertiser = m.group(1).lower()
                break
    rest = [l for l in cands if l != cta and l != advertiser and not DOMAIN_RE.fullmatch(l)]
    if not title and rest:
        title = max(rest[:6], key=len)
    if not advertiser:
        short = [l for l in rest if l != title and 1 < len(l) <= 30]
        if short:
            advertiser = short[0]
    if not advertiser and landing_url:
        host = urlparse(landing_url).hostname or ""
        advertiser = host[4:] if host.startswith("www.") else host
    return advertiser.strip(), title.strip(), cta.strip()

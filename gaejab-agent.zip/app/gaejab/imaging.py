"""이미지 지문(dHash) — 광고 ID를 못 얻었을 때 '같은 광고인지' 판정용."""
from PIL import Image


def dhash(path, size=8):
    try:
        with Image.open(path) as im:
            im = im.convert("L").resize((size + 1, size), Image.LANCZOS)
            px = list(im.getdata())
    except Exception:
        return ""
    bits = 0
    for r in range(size):
        for c in range(size):
            bits = (bits << 1) | (1 if px[r * (size + 1) + c] > px[r * (size + 1) + c + 1] else 0)
    return f"{bits:0{size * size // 4}x}"


def hamming(a, b):
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except Exception:
        return 64


def is_mostly_blank(path):
    """검은 화면/로딩 화면 판정(첫 컷이 비었으면 해시를 다음 컷으로)."""
    try:
        with Image.open(path) as im:
            ext = im.convert("L").resize((32, 18)).getextrema()
            return ext[1] - ext[0] < 12
    except Exception:
        return True

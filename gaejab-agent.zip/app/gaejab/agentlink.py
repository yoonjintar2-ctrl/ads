"""참여자 수집기 ↔ 게재나라 서버.

- 중앙에 이미 있는 광고 목록(사이트의 data/known.json)을 받아 두고, 같은 광고는 다시 찍지 않음
- 새 광고를 찍으면 캡처를 서버로 보냄(포인트는 중앙 PC가 '새 광고'로 확인한 뒤 지급 — 후불)
- 서버로 보내는 것: 수집 전용 크롬 창에서 찍은 광고 화면과 광고 정보(광고주·문구·랜딩 주소)뿐
  (참여자 이름·파일·평소 쓰는 크롬 정보는 보내지 않음)
"""
import json
import logging
import shutil
import threading
import time
import urllib.error
import urllib.request
import uuid

from . import config, db

log = logging.getLogger("gaejab")
SITE = "https://ads.jintar.co.kr"
DEFAULT_API = "https://gaejab-api.jipsa-e3839b.workers.dev"
TOKEN_FILE = config.DATA / "agent_token.txt"
KNOWN_FILE = config.DATA / "known.json"
_known = {"keys": set(), "dh": [], "at": 0.0, "max": config.DHASH_MAX_DISTANCE}


def api_base():
    try:
        with urllib.request.urlopen(SITE + "/data/api.json", timeout=10) as r:
            return json.loads(r.read().decode()).get("api") or DEFAULT_API
    except Exception:
        return DEFAULT_API


API = None


def _api():
    global API
    if not API:
        API = api_base()
    return API


def token():
    try:
        return TOKEN_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def call(method, path, body=None, auth=True, timeout=30, raw_body=None, ctype="application/json"):
    h = {"User-Agent": "gaejab-agent", "Content-Type": ctype}
    if auth and token():
        h["Authorization"] = "Bearer " + token()
    data = raw_body if raw_body is not None else (json.dumps(body).encode() if body is not None else None)
    req = urllib.request.Request(_api() + path, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            j = json.loads(e.read().decode())
        except Exception:
            j = {"error": f"오류 {e.code}"}
        j["status"] = e.code
        j["ok"] = False
        return j
    except Exception:
        return {"ok": False, "status": 0, "error": "게재나라 서버에 연결할 수 없어요(인터넷 연결 확인)"}


def login(uid, pw):
    j = call("POST", "/api/login", {"id": uid, "pw": pw, "kind": "agent"}, auth=False)
    if j.get("ok") and j.get("token"):
        TOKEN_FILE.write_text(j["token"], encoding="utf-8")
    return j


def logout():
    try:
        beat("off", force=True)
    except Exception:
        pass
    try:
        call("POST", "/api/logout", {})
    except Exception:
        pass
    TOKEN_FILE.unlink(missing_ok=True)


# ── 중앙에 이미 있는 광고 ─────────────────────────
def refresh_known(force=False):
    if not force and time.time() - _known["at"] < 1800:
        return
    try:
        with urllib.request.urlopen(SITE + f"/data/known.json?t={int(time.time())}", timeout=30) as r:
            body = r.read()
        KNOWN_FILE.write_bytes(body)
    except Exception:
        try:
            body = KNOWN_FILE.read_bytes()
        except Exception:
            return
    try:
        j = json.loads(body.decode())
        _known["keys"] = {a[0] for a in j.get("ads", [])}
        _known["dh"] = [a[1] for a in j.get("ads", []) if a[1]]
        _known["max"] = int(j.get("dhash_max") or config.DHASH_MAX_DISTANCE)
        _known["at"] = time.time()
    except Exception:
        pass


def known(key, dh=""):
    refresh_known()
    if key and key in _known["keys"]:
        return True
    if dh:
        from .imaging import hamming
        return any(hamming(dh, x) <= _known["max"] for x in _known["dh"])
    return False


def sighting(key, placement, context=""):
    if not token() or not key:
        return

    def go():
        try:
            call("POST", "/api/agent/sighting", {"key": key, "placement": placement, "context": context[:300]})
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()


# ── 새 광고 보내기 ──────────────────────────────
def _multipart(fields, files):
    b = "----gaejab" + uuid.uuid4().hex
    out = []
    for k, v in fields.items():
        out.append(f"--{b}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n".encode() + v.encode() + b"\r\n")
    for name, data in files:
        out.append(f"--{b}\r\nContent-Disposition: form-data; name=\"{name}\"; filename=\"{name}\"\r\n"
                   f"Content-Type: image/jpeg\r\n\r\n".encode() + data + b"\r\n")
    out.append(f"--{b}--\r\n".encode())
    return b"".join(out), f"multipart/form-data; boundary={b}"


STATS = {"sent": 0, "dup": 0, "fail": 0, "last": ""}


def upload_pending(conn):
    """아직 안 보낸 새 광고를 서버로 보냄. 보낸 뒤 내 컴퓨터의 캡처는 지움(용량 절약)."""
    if not token():
        return
    rows = conn.execute("SELECT * FROM ads WHERE notes NOT LIKE 'sent:%' ORDER BY id LIMIT 5").fetchall()
    for a in rows:
        frames = conn.execute("SELECT idx, t, path, kind FROM frames WHERE ad_id=? ORDER BY idx", (a["id"],)).fetchall()
        files, fmeta = [], []
        for f in frames:
            p = config.CAPTURES / f["path"]
            if not p.exists():
                continue
            name = "landing.jpg" if f["kind"] == "landing" else f"{int(f['idx']):02d}.jpg"
            files.append((name, p.read_bytes()))
            fmeta.append({"name": name, "idx": f["idx"], "t": f["t"]})
        ctx = conn.execute("SELECT context_url, context_title FROM sightings WHERE ad_id=? ORDER BY ts LIMIT 1", (a["id"],)).fetchone()
        meta = {"key": a["ad_key"], "placement": a["placement"], "dhash": a["dhash"], "advertiser": a["advertiser"],
                "title": a["title"], "cta": a["cta"], "vid": a["ad_video_id"], "declared_url": a["declared_url"],
                "landing_url": a["landing_url"], "ad_duration": a["ad_duration"], "raw_text": (a["raw_text"] or "")[:6000],
                "context_url": ctx["context_url"] if ctx else "", "context_title": ctx["context_title"] if ctx else "",
                "frames": fmeta, "captured_at": a["captured_at"]}
        if not files:
            conn.execute("UPDATE ads SET notes='sent:empty' WHERE id=?", (a["id"],))
            conn.commit()
            continue
        body, ctype = _multipart({"meta": json.dumps(meta, ensure_ascii=False)}, files)
        j = call("POST", "/api/agent/upload", raw_body=body, ctype=ctype, timeout=120)
        if j.get("ok"):
            state = "dup" if j.get("duplicate") else "queued"
            STATS["dup" if state == "dup" else "sent"] += 1
            STATS["last"] = f"{a['advertiser'] or '광고'} · {'이미 접수된 광고' if state == 'dup' else '서버로 보냄(확인 후 포인트)'}"
            conn.execute("UPDATE ads SET notes=? WHERE id=?", ("sent:" + state, a["id"]))
            conn.commit()
            if a["frame_dir"]:
                shutil.rmtree(config.CAPTURES / a["frame_dir"], ignore_errors=True)
        elif j.get("status") in (400, 413):   # 서버가 받지 않는 데이터 → 다시 보내지 않음
            STATS["fail"] += 1
            conn.execute("UPDATE ads SET notes='sent:rejected' WHERE id=?", (a["id"],))
            conn.commit()
        else:   # 한도·네트워크 문제 → 나중에 다시
            STATS["last"] = j.get("error") or "보내기 실패(잠시 후 다시)"
            break


# ── 참여 PC 현황(사이트의 '참여 PC n대') ─────────────
AID_FILE = config.DATA / "agent_id.txt"
_beat = {"at": 0.0, "state": ""}


def agent_id():
    try:
        return AID_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        aid = uuid.uuid4().hex   # 이 컴퓨터를 구분하는 임의 번호(개인정보 아님)
        AID_FILE.write_text(aid, encoding="utf-8")
        return aid


def cur_state():
    from . import status
    c = status.read_control()
    if not c.get("want_running"):
        return "idle"
    if c.get("paused"):
        return "paused"
    if c.get("auto_paused"):
        return "resting"
    return "collecting"


def beat(state=None, force=False):
    if not token():
        return
    state = state or cur_state()
    if not force and state == _beat["state"] and time.time() - _beat["at"] < 120:
        return
    j = call("POST", "/api/agent/beat", {"aid": agent_id(), "state": state}, timeout=10)
    if j.get("ok"):
        _beat.update(at=time.time(), state=state)


def _loop():
    while True:
        try:
            beat()
        except Exception:
            pass
        try:
            refresh_known()
            conn = db.connect()
            try:
                upload_pending(conn)
            finally:
                conn.close()
        except Exception as e:
            log.debug("업로드 오류: %s", e)
        time.sleep(15)


def start():
    threading.Thread(target=_loop, daemon=True, name="agentlink").start()

"""유튜브 수집기 — 가로형 영상과 쇼츠를 번갈아 보면서 광고를 포착."""
import asyncio
import json
import logging
import random
import re
import shutil
import time
from pathlib import Path
from urllib.parse import quote, urlparse, parse_qs

from . import config, db, status
from .adintel import AdIntel, clean_lines, guess_fields
from .imaging import dhash, is_mostly_blank

log = logging.getLogger("gaejab")
PLATFORM = "youtube"


class BotCheck(Exception):
    pass


class Paused(Exception):
    pass


# ── 페이지에서 실행하는 스크립트 ─────────────────────────
# 모바일 시청 페이지: 플레이어 바로 아래 붙는 광고 카드(광고주명 · 스폰서 · 도메인 · 사이트 방문)
MOBILE_COMPANION_JS = r"""
() => {
  const player = document.querySelector('#movie_player, .html5-video-player');
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (w.nextNode()) {
    const t = w.currentNode.nodeValue.trim();
    if (!/^스폰서|^Sponsored/.test(t)) continue;
    let e = w.currentNode.parentElement;
    if (!e || (player && player.contains(e))) continue;
    const r0 = e.getBoundingClientRect();
    if (r0.height === 0 || r0.top > innerHeight) continue;
    // 버튼(사이트 방문 등)까지 포함하는 가장 작은 상위 요소
    let box = e;
    for (let i = 0; i < 8 && box.parentElement; i++) {
      if (box.querySelector('button, a[href], [role=button]') && (box.innerText || '').split('\n').length >= 3) break;
      box = box.parentElement;
    }
    const lines = (box.innerText || '').split('\n').map(x => x.trim()).filter(Boolean).slice(0, 12);
    const links = [...box.querySelectorAll('a[href]')].map(a => a.href).slice(0, 10);
    return {lines, links, tag: box.tagName.toLowerCase()};
  }
  return null;
}
"""

LONGFORM_STATE_JS = r"""
() => {
  const p = document.querySelector('#movie_player, .html5-video-player');
  if (!p) return {ok:false, url: location.href};
  const cls = p.className || '';
  const ad = /\bad-showing\b|\bad-interrupting\b/.test(cls);
  let vd = {}; try { vd = (p.getVideoData && p.getVideoData()) || {}; } catch(e) {}
  const v = p.querySelector('video');
  let t = 0, dur = 0, paused = true;
  if (v) { t = v.currentTime || 0; dur = isFinite(v.duration) ? v.duration : 0; paused = v.paused; }
  let st = -1; try { st = p.getPlayerState(); } catch(e) {}
  let adText = '', links = [], labels = [];
  if (ad) {
    const boxes = p.querySelectorAll('.video-ads, .ytp-ad-module, .ytp-ad-player-overlay-layout, .ytp-ad-player-overlay, [class*="ytp-ad-"]');
    const seen = new Set(); const parts = [];
    boxes.forEach(el => {
      let anc = el.parentElement, dup = false;
      while (anc && anc !== p) { if (seen.has(anc)) { dup = true; break; } anc = anc.parentElement; }
      if (dup) return; seen.add(el);
      // 글자 조각을 요소 단위로 따로 모음(버튼 문구가 붙어버리지 않게)
      const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      while (w.nextNode()) { const tx = w.currentNode.nodeValue.trim(); if (tx) parts.push(tx); }
      el.querySelectorAll('a[href]').forEach(a => links.push(a.href));
      el.querySelectorAll('[aria-label]').forEach(b => labels.push(b.getAttribute('aria-label')));
    });
    adText = parts.join('\n');
  }
  const contentId = new URLSearchParams(location.search).get('v') || '';
  const h1 = document.querySelector('ytd-watch-metadata h1, #title h1, h1.title');
  return {ok:true, ad, vid: vd.video_id || '', vtitle: vd.title || '', vauthor: vd.author || '',
          contentId, t, dur, paused, st, adText, links: [...new Set(links)].slice(0,15),
          labels: [...new Set(labels)].slice(0,20), pageTitle: h1 ? h1.innerText.trim() : document.title,
          url: location.href,
          created: /\bad-created\b/.test(cls),
          skip: !!p.querySelector('.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-ad-skip-button-slot button'),
          fs: getComputedStyle(p).position === 'fixed',
          err: (() => { const e = p.querySelector('.ytp-error'); return !!(e && e.offsetParent !== null && getComputedStyle(e).display !== 'none'); })(),
          errText: (() => { const e = p.querySelector('.ytp-error'); return e ? (e.innerText || '').trim().slice(0, 120) : ''; })()};
}
"""

SHORTS_STATE_JS = r"""
() => {
  // 쇼츠는 영상 틀(ytd-reel-video-renderer) 하나를 재사용하고, 광고면 is-ads-overlay 속성과 광고 슬롯이 붙음
  const sh = document.querySelector('ytd-shorts');
  const r = document.querySelector('ytd-reel-video-renderer[is-active]') ||
            (sh && sh.querySelector('ytd-reel-video-renderer#reel-video-renderer')) ||
            document.querySelector('ytd-reel-video-renderer');
  if (!r) return {ok:false, url: location.href};
  const slot = sh ? sh.querySelector('ytd-ad-slot-renderer') : null;
  const meta = sh ? sh.querySelector('reels-ad-metadata-view-model, yt-ad-metadata-shape') : null;
  const vis = el => !!(el && (el.offsetParent !== null || el.getClientRects().length));
  const ad = r.hasAttribute('is-ads-overlay') || vis(meta) ||
             !!r.querySelector('ad-badge-view-model, ytd-ad-slot-renderer, [class*="AdBadge"]');
  const box = (ad && slot) ? slot : r;
  const txt = (box.innerText || '') + (box !== r ? '\n' + (r.innerText || '').slice(0, 800) : '');
  const v = (sh && sh.querySelector('#shorts-player video')) || r.querySelector('video') || document.querySelector('ytd-shorts video');
  let data = ''; try { const d = (slot && (slot.data || (slot.__data && slot.__data.data))) || r.data || (r.__data && r.__data.data);
    if (d) data = JSON.stringify(d).slice(0, 400000); } catch(e) {}
  const links = [...box.querySelectorAll('a[href]')].map(a => a.href)
      .filter(h => !/youtube\.com\/(@|channel|shorts|hashtag|watch|feed|results|$)/.test(h)).slice(0, 15);
  const labels = [...box.querySelectorAll('[aria-label]')].map(e => e.getAttribute('aria-label')).slice(0, 30);
  return {ok:true, ad, text: txt.slice(0, 3000), data, links, labels,
          t: v ? v.currentTime : 0, dur: (v && isFinite(v.duration)) ? v.duration : 0,
          paused: v ? v.paused : true, url: location.href};
}
"""


# 인피드(검색 결과·추천 목록 사이의 '스폰서' 카드) 찾기
INFEED_SCAN_JS = r"""
(mobile) => {
  const sels = mobile
    ? ['ytm-ad-slot-renderer', 'ytm-promoted-sparkles-web-renderer', 'ytm-promoted-video-renderer',
       'ytm-in-feed-ad-layout-renderer', 'ytm-display-ad-renderer', 'ytm-companion-ad-renderer']
    : ['ytd-ad-slot-renderer', 'ytd-in-feed-ad-layout-renderer', 'ytd-promoted-sparkles-web-renderer',
       'ytd-promoted-video-renderer', 'ytd-search-pyv-renderer', 'ytd-display-ad-renderer'];
  const isAdBox = e => e && e.matches && sels.some(s => e.matches(s));
  const seen = new Set(), out = [];
  for (const sel of sels) for (const el of document.querySelectorAll(sel)) {
    let top = el, p = el.parentElement;
    while (p) { if (isAdBox(p)) top = p; p = p.parentElement; }
    if (seen.has(top)) continue; seen.add(top);
    // 동영상 광고에 붙어 나오는 동반 배너, 플레이어, 쇼츠 영역은 제외(인스트림 쪽에서 이미 처리)
    if (top.closest('#player-ads, ytd-player, #movie_player, .html5-video-player, ytd-shorts, ytm-shorts-lockup-view-model')) continue;
    if (top.dataset.gaejabDone) continue;
    const r = top.getBoundingClientRect();
    if (r.width < 120 || r.height < 50) continue;
    const txt = (top.innerText || '').trim();
    if (!txt) continue;
    const id = 'g' + Math.random().toString(36).slice(2, 10);
    top.dataset.gaejabId = id;
    const links = [...top.querySelectorAll('a[href]')].map(a => a.href);
    let vid = '';
    for (const h of links) { const m = h.match(/[?&]v=([\w-]{11})/) || h.match(/\/shorts\/([\w-]{11})/); if (m) { vid = m[1]; break; } }
    out.push({id, text: txt.slice(0, 1500), links: links.slice(0, 15), vid,
              labels: [...top.querySelectorAll('[aria-label]')].map(e => e.getAttribute('aria-label')).slice(0, 20),
              html: top.outerHTML.slice(0, 60000)});
  }
  return out.slice(0, 3);
}
"""
# 인피드 카드를 화면 가운데로 가져오고, 1회 클릭할 버튼(CTA)에 표시
INFEED_FOCUS_JS = r"""
(id) => {
  const el = document.querySelector('[data-gaejab-id="' + id + '"]');
  if (!el) return false;
  el.dataset.gaejabDone = '1';
  el.scrollIntoView({block: 'center'});
  document.querySelectorAll('[data-gaejab-cta]').forEach(e => e.removeAttribute('data-gaejab-cta'));
  const re = /자세히|알아보기|설치|구매|구입|쇼핑|방문|신청|예약|다운로드|바로가기|시작하기|플레이|Learn|Shop|Install|Visit|Download|Sign up|Book|Get|Play/i;
  // 카드 전체를 감싼 링크가 아니라, 문구가 짧은 실제 버튼을 고름
  const label = b => (b.innerText || b.getAttribute('aria-label') || '').trim();
  const vis = b => { const r = b.getBoundingClientRect(); return r.width > 8 && r.height > 8; };
  const cands = [...el.querySelectorAll('button, a[href], [role="button"]')].filter(vis);
  let cta = cands.find(b => label(b).length <= 20 && re.test(label(b)));
  if (!cta) cta = cands.find(a => a.href && /googleadservices|doubleclick|aclk/.test(a.href) && label(a).length <= 30);
  if (cta) cta.setAttribute('data-gaejab-cta', '1');
  return true;
}
"""
# 모바일 쇼츠: 화면 가운데 영상 + 광고 표시('스폰서')
MSHORTS_STATE_JS = r"""
() => {
  const H = innerHeight, W = innerWidth;
  const inView = el => { const r = el.getBoundingClientRect(); return r.height > 0 && r.bottom > 0 && r.top < H && r.right > 0 && r.left < W; };
  const v = [...document.querySelectorAll('video')].find(v => { const r = v.getBoundingClientRect(); return r.height > 150 && r.top < H * 0.6 && r.bottom > H * 0.4; }) || null;
  let root = v;
  for (let i = 0; i < 12 && root && root.parentElement; i++) { root = root.parentElement; const r = root.getBoundingClientRect(); if (r.height >= H * 0.85 && r.width >= W * 0.9) break; }
  root = root || document.body;
  const badges = [...document.querySelectorAll('ad-badge-view-model, badge-shape, [class*="ad-badge"], [class*="AdBadge"], [class*="adBadge"]')]
      .filter(b => inView(b) && /스폰서|Sponsored|광고/.test(b.innerText || b.getAttribute('aria-label') || ''));
  // 화면에 실제로 보이는 글자만 모음(광고주명·문구·버튼은 화면 아래쪽 오버레이에 있음)
  const seenT = new Set(), parts = [];
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (w.nextNode()) {
    const tx = w.currentNode.nodeValue.trim(); if (!tx || tx.length > 160 || seenT.has(tx)) continue;
    const el = w.currentNode.parentElement; if (!el) continue;
    const r = el.getBoundingClientRect();
    if (r.height > 0 && r.top >= H * 0.4 && r.bottom <= H + 2 && r.left < W && r.right > 0) { seenT.add(tx); parts.push(tx); }
  }
  const rootText = parts.join('\n');
  const ad = badges.length > 0 || /(^|\n|·)\s*(스폰서|Sponsored)\s*(·|\n|$)/.test(rootText);
  document.querySelectorAll('[data-gaejab-cta]').forEach(e => e.removeAttribute('data-gaejab-cta'));
  let links = [], labels = [];
  if (ad) {
    const re = /자세히|알아보기|설치|구매|구입|쇼핑|방문|신청|예약|다운로드|바로가기|시작하기|플레이|Learn|Shop|Install|Visit|Download|Book|Get|Play/i;
    const label = b => (b.innerText || b.getAttribute('aria-label') || '').trim();
    const cands = [...document.querySelectorAll('a[href], button, [role="button"]')].filter(inView);
    // 광고 클릭 URL이 걸린 버튼을 먼저(유튜브 채널·영상으로 가는 링크는 랜딩이 아님)
    let cta = cands.find(a => a.href && /googleadservices|doubleclick|aclk/.test(a.href));
    if (!cta) cta = cands.find(b => label(b).length <= 20 && re.test(label(b)) && !(b.href && /youtube\.com/.test(b.href)));
    if (cta) cta.setAttribute('data-gaejab-cta', '1');
    links = cands.filter(a => a.href && !/youtube\.com|accounts\.google|google\.com\/(intl|policies)|support\.google/.test(a.href)).map(a => a.href).slice(0, 15);
    labels = [];
  }
  return {ok: !!v, ad, text: rootText.slice(0, 3000), links, labels, data: '',
          t: v ? v.currentTime : 0, dur: (v && isFinite(v.duration)) ? v.duration : 0,
          paused: v ? v.paused : true, url: location.href};
}
"""
MARKED_CTA = ["[data-gaejab-cta='1']"]

# 진단용: 광고가 떴을 때 플레이어가 들고 있는 광고 데이터와 광고 영역 HTML을 그대로 저장
DIAG_LONGFORM_JS = r"""
() => { const p = document.querySelector('#movie_player, .html5-video-player'); const out = {};
  try { const r = p.getPlayerResponse && p.getPlayerResponse();
        if (r) { out.pr_keys = Object.keys(r); out.adPlacements = r.adPlacements || null;
                 out.playerAds = r.playerAds || null; out.adSlots = r.adSlots || null; } } catch(e) { out.err = String(e); }
  try { out.videoData = p.getVideoData && p.getVideoData(); } catch(e) {}
  try { const w = window.ytInitialPlayerResponse;
        if (w) { out.init_adPlacements = w.adPlacements || null; out.init_playerAds = w.playerAds || null;
                 out.init_adSlots = w.adSlots || null; } } catch(e) {}
  const box = p.querySelector('.video-ads'); out.ad_dom = box ? box.outerHTML.slice(0, 120000) : '';
  out.player_class = p.className;
  // 필드별로 잘라서 항상 올바른 JSON이 되게
  const res = {};
  for (const [k, v] of Object.entries(out)) {
    let j; try { j = JSON.stringify(v); } catch(e) { j = JSON.stringify(String(v)); }
    res[k] = (j && j.length > 300000) ? JSON.stringify({truncated: j.slice(0, 300000)}) : (j || 'null');
  }
  return '{' + Object.entries(res).map(([k, v]) => JSON.stringify(k) + ':' + v).join(',') + '}'; }
"""
DIAG_SHORTS_JS = r"""
() => { const r = document.querySelector('ytd-reel-video-renderer[is-active]');
  return JSON.stringify({ad_dom: r ? r.outerHTML.slice(0, 150000) : '', url: location.href}); }
"""

# 전체화면과 같은 1920×1080 화면을 OS 전체화면 전환 없이 만듦(사용 중인 화면을 방해하지 않음)
PSEUDO_FS_CSS = """
#movie_player, #movie_player.ytp-fullscreen { position: fixed !important; inset: 0 !important;
  width: 100vw !important; height: 100vh !important; z-index: 2147483000 !important; background:#000 !important; }
#movie_player video.html5-main-video { width: 100vw !important; height: 100vh !important; left:0 !important; top:0 !important;
  object-fit: contain !important; }
ytd-masthead, #masthead-container { display: none !important; }
html, body { overflow: hidden !important; }
"""

LONGFORM_CLICK_SELECTORS = [
    ".ytp-ad-visit-advertiser-button",
    ".ytp-visit-advertiser-link",
    ".ytp-ad-player-overlay-layout__ad-info-container a",
    ".ytp-ad-button.ytp-ad-visit-advertiser-button",
    ".ytp-ad-component--clickable",
    ".ytp-ad-overlay-link",
    "[class*='visit-advertiser']",
    ".ytp-ad-player-overlay-layout a[href]",
    ".video-ads a[href^='http']",
]
_AR = "ytd-shorts "
SHORTS_CLICK_SELECTORS = [
    _AR + "ad-button-view-model a[href]", _AR + "reels-ad-metadata-view-model",
    _AR + "a[href*='googleadservices']", _AR + "a[href*='doubleclick']",
    _AR + "ytd-ad-slot-renderer a[href]", _AR + "[class*='call-to-action'] button", _AR + "[class*='cta'] button",
    _AR + ":is(a,button):text-matches('자세히|알아보기|설치|구매|구입|쇼핑|방문|신청|예약|다운로드|바로가기|"
          "Learn more|Shop|Install|Sign up|Visit|Download|Book|Get', 'i')",
    _AR + "a[href^='http']:not([href*='youtube.com'])",
]
SKIP_SELECTORS = [".ytp-skip-ad-button", ".ytp-ad-skip-button-modern", ".ytp-ad-skip-button",
                  ".ytp-ad-skip-button-slot button"]
POPUP_DISMISS_TEXTS = ["모두 거부", "Reject all", "나중에", "괜찮습니다", "No thanks", "Not now", "닫기", "Dismiss"]


def _safe(s):
    return re.sub(r"[^A-Za-z0-9_-]", "_", s)[:60]


class YouTubeCrawler:
    def __init__(self, context, liveview, shooter):
        self.ctx = context
        self.live = liveview
        self.shooter = shooter
        self.page = None
        self.pc_page = None
        self.m_page = None
        self.mobile = False
        self.intel = AdIntel()
        self.conn = db.connect()
        self.last_cookie_clear = time.time()
        self.genre = ""

    # ── 공통 ──────────────────────────────────────────
    async def open(self):
        pages = self.ctx.pages
        self.page = pages[0] if pages else await self.ctx.new_page()
        for p in pages[1:]:
            await p.close()
        self.pc_page = self.page
        self.page.on("response", lambda r: asyncio.ensure_future(self.intel.on_response(r)))
        self.live.page = self.page
        await self.shooter.locate(self.page)

    async def close_mobile(self):
        """모바일 탭은 라운드가 끝나면 닫음 → PC 게재보고 캡처에 다른 탭이 보이지 않게."""
        if self.m_page is not None and not self.m_page.is_closed():
            try:
                await self.m_page.close()
            except Exception:
                pass
        self.m_page = None

    async def close_extra_tabs(self):
        """광고와 상관없는 탭은 모두 닫음(PC 캡처에는 광고가 재생 중인 유튜브 탭 하나만)."""
        keep = {id(self.page)}
        for p in list(self.ctx.pages):
            if id(p) not in keep:
                try:
                    await p.close()
                except Exception:
                    pass
        if self.m_page is not None and self.m_page.is_closed():
            self.m_page = None

    async def use_pc(self):
        await self.close_mobile()
        self.mobile = False
        self.page = self.pc_page
        self.live.page, self.live.window = self.page, True
        await self.page.bring_to_front()

    async def use_mobile(self):
        """같은 크롬 안에 안드로이드 폰처럼 보이는 탭을 하나 두고 모바일 웹으로 접속."""
        if self.m_page is None or self.m_page.is_closed():
            self.m_page = await self.ctx.new_page()
            cdp = await self.ctx.new_cdp_session(self.m_page)
            sc = config.MOBILE_SCREEN
            await cdp.send("Emulation.setDeviceMetricsOverride", {
                "width": sc["width"], "height": sc["height"], "deviceScaleFactor": sc["scale"], "mobile": True,
                "screenWidth": sc["width"], "screenHeight": sc["height"]})
            await cdp.send("Emulation.setTouchEmulationEnabled", {"enabled": True, "maxTouchPoints": 5})
            await cdp.send("Emulation.setUserAgentOverride", {
                "userAgent": config.MOBILE_UA, "acceptLanguage": "ko-KR,ko;q=0.9", "platform": "Linux armv8l",
                "userAgentMetadata": {"brands": [{"brand": "Chromium", "version": "141"},
                                                 {"brand": "Google Chrome", "version": "141"}],
                                      "fullVersion": "141.0.0.0", "platform": "Android", "platformVersion": "14.0.0",
                                      "architecture": "", "model": "SM-S911N", "mobile": True}})
            # '탭하여 음소거 해제' 안내 버튼이 게재보고 캡처에 안 보이게(투명 처리, 터치는 그대로 받음)
            await self.m_page.add_init_script("""(() => {
              const css = '.ytp-unmute,.ytp-unmute-inner,.ytp-unmute-text{opacity:0!important;}';
              const add = () => { if (document.getElementById('gj-hide')) return;
                const s = document.createElement('style'); s.id = 'gj-hide'; s.textContent = css;
                (document.head || document.documentElement).appendChild(s); };
              if (document.documentElement) add(); document.addEventListener('DOMContentLoaded', add);
            })()""")
            self.m_page.on("response", lambda r: asyncio.ensure_future(self.intel.on_response(r)))
            self._m_cdp = cdp
            self.shooter.cdp[id(self.m_page)] = cdp
        self.mobile = True
        self.page = self.m_page
        self.live.page, self.live.window = self.page, False
        await self.page.bring_to_front()

    async def goto(self, url, settle=True):
        await self.page.goto(url, wait_until="domcontentloaded", timeout=45000)
        if settle:  # 시청 페이지는 바로 감시 시작(프리롤 첫 장면을 놓치지 않게)
            await asyncio.sleep(random.uniform(1.5, 3))
        await self.check_bot()
        await self.dismiss_popups()
        # 첫 화면에 실려 오는 플레이어 데이터(광고 정보 포함)도 읽어 둠
        for var in ("ytInitialPlayerResponse", "ytInitialData"):
            try:
                txt = await self.page.evaluate(f"() => window.{var} ? JSON.stringify(window.{var}) : ''")
                if txt:
                    self.intel.ingest_text(txt)
            except Exception:
                pass

    async def check_bot(self):
        url = self.page.url
        if "google.com/sorry" in url:
            raise BotCheck(url)
        try:
            body = await self.page.evaluate("() => (document.body && document.body.innerText || '').slice(0, 3000)")
        except Exception:
            body = ""
        if re.search(r"(봇이 아닌지 확인|로봇이 아닙니다|not a bot|unusual traffic)", body, re.I):
            raise BotCheck(url)

    async def dismiss_popups(self):
        for t in POPUP_DISMISS_TEXTS:
            try:
                btn = self.page.locator(
                    f"tp-yt-paper-dialog button:has-text('{t}'), ytd-consent-bump-v2-lightbox button:has-text('{t}'),"
                    f" ytd-mealbar-promo-renderer button:has-text('{t}'), ytd-popup-container button:has-text('{t}'),"
                    f" yt-mealbar-promo-renderer button:has-text('{t}'), form button:has-text('{t}')").first
                if await btn.count() and await btn.is_visible():
                    await btn.click(timeout=2000)
                    await asyncio.sleep(0.8)
            except Exception:
                pass

    def check_pause(self):
        if status.is_paused():
            raise Paused()

    async def maybe_clear_cookies(self):
        if time.time() - self.last_cookie_clear > config.CLEAR_COOKIES_EVERY_HOURS * 3600:
            await self.ctx.clear_cookies()
            self.last_cookie_clear = time.time()
            status.event("시청 기록 쏠림 방지를 위해 쿠키 초기화")

    # ── 메인 루프 ─────────────────────────────────────
    async def run_forever(self):
        await self.open()
        status.update(state="running", platform=PLATFORM)
        status.event("유튜브 수집 시작")
        turn = 0
        order = [r for r in config.ROUND_ORDER if not r.startswith("m") or config.MOBILE_ENABLED] or ["pc"]
        born = time.time()
        while True:
            if time.time() - born > config.RECYCLE_EVERY_MIN * 60:
                status.event("메모리 정리를 위해 크롬을 새로 띄웁니다")
                return "recycle"
            try:
                await self.wait_until_allowed()
                await self.maybe_clear_cookies()
                if not getattr(self, "_genre_bag", None):   # 장르를 한 바퀴씩 고르게(무작위 쏠림 방지)
                    self._genre_bag = random.sample(list(config.GENRES), len(config.GENRES))
                self.genre = self._genre_bag.pop()
                kind = order[turn % len(order)]
                turn += 1
                if kind in ("mobile", "mshorts"):
                    await self.use_mobile()
                    try:
                        if kind == "mshorts":
                            await self.mobile_shorts_round()
                        else:
                            await self.longform_round(mobile=True)
                            if random.random() < config.MOBILE_HOME_SCAN_RATE:
                                await self.mobile_home_scan()
                    finally:
                        await self.close_mobile()
                else:
                    await self.use_pc()
                    if kind == "shorts":
                        await self.shorts_round()
                    else:
                        await self.longform_round()
                await asyncio.sleep(random.uniform(*config.PAUSE_BETWEEN_SEC))
            except Paused:
                continue
            except BotCheck as e:
                status.update(state="bot_check", action=f"로봇 확인 화면 감지 → {config.BOT_CHECK_COOLDOWN_MIN}분 휴식")
                status.event(f"로봇 확인 화면 감지({e}). {config.BOT_CHECK_COOLDOWN_MIN}분 쉬었다가 재개", "warn")
                await asyncio.sleep(config.BOT_CHECK_COOLDOWN_MIN * 60)
                await self.ctx.clear_cookies()
                status.update(state="running")
            except Exception as e:
                if "closed" in str(e).lower() or "Target page" in str(e):
                    raise
                log.exception("라운드 오류")
                status.event(f"오류: {str(e)[:200]}", "error")
                await asyncio.sleep(10)

    async def wait_until_allowed(self):
        while True:
            if status.is_paused():
                status.update(state="paused", action="일시정지됨 (대시보드에서 재개)")
                await asyncio.sleep(3)
                continue
            if config.ACTIVE_HOURS:
                h = time.localtime().tm_hour
                a, b = config.ACTIVE_HOURS
                if not (a <= h < b):
                    status.update(state="waiting", action=f"가동 시간 외 ({a}시~{b}시만 수집)")
                    await asyncio.sleep(60)
                    continue
            status.update(state="running")
            return

    # ── 가로형 ───────────────────────────────────────
    def placement_now(self):
        return "youtube_mobile_instream" if self.mobile else "youtube_instream"

    async def longform_round(self, mobile=False):
        kw = random.choice(config.GENRES[self.genre])
        if mobile and self.genre in getattr(config, "COMMERCIAL_KW", {}) and random.random() < config.MOBILE_COMMERCIAL_RATE:
            kw = random.choice(config.COMMERCIAL_KW[self.genre])
        base = config.YT_MOBILE_BASE if mobile else config.YT_BASE
        label = "모바일 가로형" if mobile else "가로형"
        status.update(action=f"{label} · '{kw}' 검색", placement=self.placement_now(), genre=self.genre)
        # 모바일은 필터(동영상만) 없이 검색해야 검색 결과 사이 인피드 광고가 붙음
        flt = "" if mobile else "&sp=EgIQAQ%253D%253D"
        await self.goto(f"{base}/results?search_query={quote(kw)}{flt}")
        sel = "a[href*='/watch?v=']"
        try:
            await self.page.wait_for_selector(sel, timeout=20000)
        except Exception:
            status.event(f"{label} 검색 결과 없음: {kw}", "warn")
            return
        hrefs = await self.page.evaluate("""() => [...document.querySelectorAll("a[href*='/watch?v=']")]
            .filter(a => !a.closest('ytd-ad-slot-renderer, ytd-promoted-video-renderer, ytm-promoted-video-renderer,'
                                     + ' ytm-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, [class*="promoted"]'))
            .map(a => a.href.split('&')[0]).filter(h => h && h.includes('/watch?v='))""")
        hrefs = list(dict.fromkeys(hrefs))
        await self.scan_infeed(f"검색: {kw}")
        if not hrefs:
            return
        url = random.choice(hrefs[:12])
        log.info("%s 라운드 · 장르=%s 검색어=%s → %s", label, self.genre, kw, url)
        await self.watch_longform(url, tap=mobile)
        # 같은 라운드에서 추천 영상으로 몇 개 더 이어 보기(검색 페이지를 매번 다시 열지 않아 빠름)
        seen = {url.split("v=")[-1][:11]}
        for _ in range(random.randint(*(config.VIDEOS_PER_ROUND if mobile else config.PC_VIDEOS_PER_ROUND)) - 1):
            if status.is_paused():
                return
            nxt = []
            for attempt in range(3):
                try:
                    found = await self.page.evaluate("""() => [...document.querySelectorAll("a[href*='/watch?v=']")]
                        .filter(a => !a.closest('ytd-ad-slot-renderer, ytm-ad-slot-renderer, ytd-in-feed-ad-layout-renderer,'
                                                + ' [class*="promoted"], #movie_player, .html5-video-player'))
                        .filter(a => { const r = a.getBoundingClientRect(); return r.width > 40 && r.height > 20; })
                        .map(a => a.href.split('&')[0])""")
                except Exception as e:
                    log.info("%s 이어보기 목록 읽기 실패: %s", label, str(e)[:80])
                    found = []
                nxt = [h for h in dict.fromkeys(found) if h.split("v=")[-1][:11] not in seen]
                if nxt:
                    break
                # 추천 목록이 아직 안 그려졌으면 조금 내려서 불러옴
                try:
                    await self.page.evaluate("() => window.scrollBy(0, 900)")
                except Exception:
                    pass
                await asyncio.sleep(1.5)
            if not nxt:
                log.info("%s 이어볼 추천 영상을 못 찾아 라운드 종료", label)
                return
            url = random.choice(nxt[:10])
            seen.add(url.split("v=")[-1][:11])
            log.info("%s 이어보기 → %s", label, url)
            await self.watch_longform(url, tap=mobile)

    async def mobile_home_scan(self):
        """모바일 홈 피드를 몇 화면 내려 보며 인피드 광고 확인(홈 피드 광고 지면)."""
        try:
            await self.goto(config.YT_MOBILE_BASE + "/")
            await asyncio.sleep(1.5)
            log.info("모바일 홈 피드 확인")
            await self.scan_infeed("모바일 홈 피드")
        except Exception as e:
            log.info("모바일 홈 피드 확인 실패: %s", str(e)[:80])

    async def tap_result(self, url):
        """모바일: 검색 결과를 손가락으로 누른 것처럼 들어감(사용자 조작으로 진입해야 프리롤이 재생됨)."""
        cdp = getattr(self, "_m_cdp", None)
        vid = url.split("v=")[-1][:11]
        if not cdp or not vid:
            return False
        try:
            pt = await self.page.evaluate("""(vid) => {
                const a = [...document.querySelectorAll("a[href*='/watch?v=" + vid + "']")]
                  .find(e => { const r = e.getBoundingClientRect(); return r.width > 20 && r.height > 20; });
                if (!a) return null;
                a.scrollIntoView({block: 'center'});
                const r = a.getBoundingClientRect();
                return {x: r.left + Math.min(r.width / 2, 150), y: r.top + r.height / 2};
            }""", vid)
            if not pt:
                return False
            await asyncio.sleep(random.uniform(0.6, 1.2))
            tp = [{"x": pt["x"], "y": pt["y"]}]
            await cdp.send("Input.dispatchTouchEvent", {"type": "touchStart", "touchPoints": tp})
            await asyncio.sleep(random.uniform(0.06, 0.12))
            await cdp.send("Input.dispatchTouchEvent", {"type": "touchEnd", "touchPoints": []})
            await self.page.wait_for_url("**/watch?v=*", timeout=15000)
            log.info("모바일: 검색 결과 터치로 진입")
            await self.dismiss_popups()
            return True
        except Exception as e:
            log.info("모바일: 검색 결과 터치 진입 실패 → 주소로 이동 (%s)", str(e)[:80])
            return False

    async def watch_longform(self, url, tap=False):
        """프리롤만 수집: 영상에 들어가서 잠깐 기다려 광고가 뜨면 잡고, 안 뜨면 바로 다음 영상."""
        tapped = tap and self.mobile and await self.tap_result(url)
        if not tapped:
            await self.goto(url, settle=False)
        try:
            await self.page.wait_for_selector("#movie_player, .html5-video-player", timeout=20000)
        except Exception:
            return
        if config.YT_FULLSCREEN and not self.mobile:
            await self.apply_fullscreen()
        status.bump("videos")
        wait_sec = random.uniform(*config.PREROLL_WAIT_SEC)
        start = time.time()
        title = ""
        saw_ad = False
        after_until = None
        taps = 0
        extended = False
        st_created = False
        if self.mobile:
            # 모바일 웹은 사람이 화면을 한 번 눌러야 프리롤이 재생되는 경우가 많음 → 실제 터치 1회
            await asyncio.sleep(1.2)
            if await self.mobile_tap_player():
                taps = 1
            try:   # 실제 음소거 해제(브라우저 자체가 무음이라 소리는 안 남) → 안내 버튼도 사라짐
                await self.page.evaluate("""() => { const p = document.querySelector('#movie_player, .html5-video-player');
                    try { p && p.unMute && p.unMute(); } catch (e) {}
                    const v = document.querySelector('video'); if (v) v.muted = false; }""")
            except Exception:
                pass
        while True:
            now = time.time()
            if after_until is not None and now > after_until:
                break
            if after_until is None and now - start > wait_sec:
                # 광고는 만들어졌는데(ad-created) 아직 안 뜬 상태면 한 번 더 누르고 조금 더 기다림
                if not extended and self.mobile and st_created:
                    extended = True
                    wait_sec += 8
                    if taps < 2 and await self.mobile_tap_player():
                        taps += 1
                    log.info("모바일: 광고 준비됨(ad-created) → 추가 대기")
                    continue
                break
            st = await self.page.evaluate(LONGFORM_STATE_JS)
            st_created = bool(st.get("created")) if st.get("ok") else False
            if not st.get("ok"):
                await asyncio.sleep(0.5)
                continue
            if st.get("err"):
                status.event(f"재생 오류 화면 → 다음 영상으로 ({st.get('errText', '')[:60]})", "warn")
                return
            if st["ad"]:
                saw_ad = True
                await self.handle_longform_ad(st)
                # 광고가 끝나면 본편을 잠깐 보고(연속 광고 확인) 이동
                after_until = time.time() + random.uniform(*config.AFTER_AD_WATCH_SEC)
                continue
            title = st.get("pageTitle") or title
            status.update(action=f"{'모바일 ' if self.mobile else ''}가로형 · 프리롤 대기 중 · {title[:40]}",
                          context_url=st["url"], context_title=title, placement=self.placement_now())
            if st.get("paused") and not saw_ad and now - start > 2:
                await self.resume_longform()
            if status.is_paused():
                return
            await asyncio.sleep(0.3)
        if not saw_ad:
            log.info("프리롤 없음 → 다음 영상 (%s)", url)
            if self.mobile:
                await self.mobile_ad_diag("mwatch2")
        # 시청 페이지의 추천 목록 사이 인피드 광고
        await self.scan_infeed(title or url)

    async def mobile_tap_player(self):
        """모바일 탭에서 플레이어를 실제 터치 이벤트로 한 번 누름(음소거 해제 버튼이 있으면 그것을)."""
        cdp = getattr(self, "_m_cdp", None)
        if not cdp:
            return False
        try:
            pt = await self.page.evaluate("""() => {
                const vis = e => { if (!e) return null; const r = e.getBoundingClientRect();
                  return (r.width > 4 && r.height > 4 && r.bottom > 0 && r.top < innerHeight) ? r : null; };
                const cands = [...document.querySelectorAll('button, [role=button], .ytp-unmute, [class*="unmute"], [class*="Unmute"]')]
                  .filter(e => /음소거 해제|탭하여|unmute/i.test((e.getAttribute('aria-label') || '') + ' ' + (e.className || '') + ' ' + (e.innerText || '')));
                for (const c of cands) { const r = vis(c); if (r) return {x: r.left + r.width / 2, y: r.top + r.height / 2, what: 'unmute'}; }
                const p = vis(document.querySelector('#movie_player, .html5-video-player, #player-container-id'));
                if (p) return {x: p.left + p.width / 2, y: p.top + p.height / 2, what: 'player'};
                return null;
            }""")
            if not pt:
                return False
            tp = [{"x": pt["x"], "y": pt["y"]}]
            await cdp.send("Input.dispatchTouchEvent", {"type": "touchStart", "touchPoints": tp})
            await asyncio.sleep(random.uniform(0.06, 0.12))
            await cdp.send("Input.dispatchTouchEvent", {"type": "touchEnd", "touchPoints": []})
            log.info("모바일: 플레이어 터치(%s)", pt.get("what"))
            return True
        except Exception as e:
            log.debug("모바일 터치 실패: %s", e)
            return False

    async def mobile_watch_diag(self, url):
        """모바일 프리롤이 안 잡히는 원인 분석용: 플레이어 상태와 화면을 하루 12건까지 저장."""
        d = config.DATA / "diag"
        d.mkdir(exist_ok=True)
        today = db.today()
        if len(list(d.glob(f"mwatch_{today}_*.json"))) >= 12:
            return
        try:
            info = await self.page.evaluate("""() => {
                const ps = [...document.querySelectorAll('#movie_player, .html5-video-player, ytm-player, #player, #player-container-id')]
                  .map(e => ({tag: e.tagName, id: e.id, cls: String(e.className).slice(0, 300)}));
                const vids = [...document.querySelectorAll('video')].map(v => ({src: (v.currentSrc || '').slice(0, 80), t: v.currentTime,
                  dur: v.duration, paused: v.paused, muted: v.muted, w: v.videoWidth}));
                const adish = [...document.querySelectorAll('[class*="ad-"], [class*="-ad"], [class*="Ad"]')].slice(0, 40)
                  .map(e => e.tagName + '.' + String(e.className).slice(0, 80));
                const txt = (document.body.innerText || '').match(/.{0,30}(스폰서|광고|Sponsored).{0,30}/g) || [];
                return {url: location.href, ua: navigator.userAgent, players: ps, videos: vids, adish, txt: txt.slice(0, 10),
                        player_html: (document.querySelector('#player-container-id, #player, .html5-video-player') || {outerHTML: ''}).outerHTML.slice(0, 60000)};
            }""")
            name = d / f"mwatch_{today}_{int(time.time())}"
            name.with_suffix(".json").write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding="utf-8")
            await self.page.screenshot(path=str(name.with_suffix(".jpg")), type="jpeg", quality=70)
        except Exception as e:
            log.warning("모바일 진단 저장 실패: %s", e)

    async def handle_longform_ad(self, st):
        status.bump("ads_detected")
        base = config.YT_MOBILE_BASE if self.mobile else config.YT_BASE
        context_url = f"{base}/watch?v={st.get('contentId')}" if st.get("contentId") else st["url"]
        context_title = st.get("pageTitle", "")
        vid = st["vid"] if st.get("vid") and st["vid"] != st.get("contentId") else ""
        await asyncio.sleep(0.3)  # 광고 문구가 그려질 시간
        st2 = await self.page.evaluate(LONGFORM_STATE_JS)
        if st2.get("ok") and st2.get("ad"):
            st = st2
            if not vid and st.get("vid") and st["vid"] != st.get("contentId"):
                vid = st["vid"]
        declared, click_url, hints = self.intel.lookup(vid)
        for link in st.get("links", []):
            if not declared and ("adurl=" in link or "googleadservices" in link):
                from .adintel import declared_from_click
                declared, click_url = declared_from_click(link), link
        comp = None
        if self.mobile:
            try:
                comp = await self.page.evaluate(MOBILE_COMPANION_JS)
            except Exception:
                comp = None
        if comp:
            for link in comp.get("links", []):
                if not declared and ("adurl=" in link or "googleadservices" in link or "/aclk" in link):
                    from .adintel import declared_from_click
                    declared, click_url = declared_from_click(link), link
        comp_text = "\n".join(comp.get("lines", [])) + "\n" if comp else ""
        lines = clean_lines(comp_text + st.get("adText", "") + "\n" + "\n".join(st.get("labels", [])))
        debug = {"state": st, "companion": comp}
        try:
            debug["player"] = json.loads(await self.page.evaluate(DIAG_LONGFORM_JS))
        except Exception as e:
            debug["player_error"] = str(e)
        info = {
            "debug": debug,
            "placement": self.placement_now(), "vid": vid, "declared": declared, "click_url": click_url,
            "lines": lines, "hints": hints, "vtitle": st.get("vtitle", "") if vid else "",
            "vauthor": st.get("vauthor", "") if vid else "", "dur": st.get("dur", 0),
            "context_url": context_url, "context_title": context_title,
        }

        async def get_state():
            s = await self.page.evaluate(LONGFORM_STATE_JS)
            alive = s.get("ok") and s.get("ad") and (not vid or s.get("vid") in ("", vid))
            return alive, s.get("t", 0), s.get("dur", 0)

        log.info(
            "%s 광고 감지 · vid=%s 광고길이=%.1f 문구=%s 설정랜딩=%s", "모바일" if self.mobile else "가로형", vid or "-",
            st.get("dur", 0), " | ".join(lines[:6]), declared or "-")
        await self.process_ad(info, get_state, shot=self.shot_viewport,
                              click_selectors=LONGFORM_CLICK_SELECTORS, resume=self.resume_longform)
        # 광고 끝 처리: 건너뛸 수 있으면 건너뛰고, 아니면 끝날 때까지 대기
        t0 = time.time()
        while time.time() - t0 < 150:
            s = await self.page.evaluate(LONGFORM_STATE_JS)
            if not (s.get("ok") and s.get("ad")):
                return
            if vid and s.get("vid") and s["vid"] not in (vid, s.get("contentId")):
                return  # 연속 광고의 다음 광고 → 메인 루프에서 새로 처리
            if s.get("skip"):
                await self.click_first(SKIP_SELECTORS)
            if s.get("paused"):
                await self.resume_longform()
            await asyncio.sleep(0.5)

    async def apply_fullscreen(self):
        """플레이어를 화면 전체(1920×1080)로 키움. 실패하면 로그에 경고."""
        ok = await self.page.evaluate("""(css) => {
            try { if (!window.__gaejabSheet) { const sh = new CSSStyleSheet(); sh.replaceSync(css);
                  document.adoptedStyleSheets = [...document.adoptedStyleSheets, sh]; window.__gaejabSheet = sh; } } catch(e) {}
            if (!document.getElementById('gaejab-fs')) { const s = document.createElement('style'); s.id = 'gaejab-fs';
                  s.textContent = css; document.head.appendChild(s); }
            window.dispatchEvent(new Event('resize'));
            const p = document.querySelector('#movie_player, .html5-video-player');
            return !!p && getComputedStyle(p).position === 'fixed'; }""", PSEUDO_FS_CSS)
        if not ok and not getattr(self, "_fs_warned", False):
            self._fs_warned = True
            status.event("전체화면 스타일 적용 실패 → 일반 화면으로 캡처", "warn")
        return ok

    async def resume_longform(self):
        await self.page.bring_to_front()
        await self.page.evaluate("() => { const p=document.querySelector('#movie_player, .html5-video-player'); try{p.playVideo()}catch(e){}"
                                 " const v=p&&p.querySelector('video'); if(v&&v.paused) v.play().catch(()=>{}); }")

    # ── 쇼츠 ─────────────────────────────────────────
    async def shorts_round(self):
        n = random.randint(*config.SHORTS_PER_ROUND)
        kw = random.choice(config.GENRES[self.genre])
        status.update(action=f"쇼츠 피드 탐색 ({n}개)", placement="youtube_shorts", genre=self.genre)
        # 장르 다양화: 검색 결과의 쇼츠 하나로 들어가서 피드를 넘김(실패하면 기본 쇼츠 피드)
        start_url = f"{config.YT_BASE}/shorts/"
        try:
            await self.goto(f"{config.YT_BASE}/results?search_query={quote(kw + ' #shorts')}")
            hrefs = await self.page.evaluate("() => [...document.querySelectorAll('a[href*=\"/shorts/\"]')].map(a=>a.href)")
            if hrefs:
                start_url = random.choice(hrefs[:10])
        except BotCheck:
            raise
        except Exception:
            pass
        log.info("쇼츠 라운드 · 장르=%s 검색어=%s → %s (%d개)", self.genre, kw, start_url, n)
        await self.goto(start_url)
        try:
            await self.page.wait_for_selector("ytd-reel-video-renderer", timeout=20000)
        except Exception:
            status.event("쇼츠 피드를 열지 못함", "warn")
            return
        last_url = ""
        for i in range(n):
            if status.is_paused():
                return
            await asyncio.sleep(random.uniform(1.0, 1.8))
            st = await self.page.evaluate(SHORTS_STATE_JS)
            if st.get("ok"):
                status.bump("shorts")
                status.update(action=f"쇼츠 {i + 1}/{n} 시청 중", context_url=st["url"],
                              context_title=f"쇼츠 피드 · {self.genre}", placement="youtube_shorts")
                if st["ad"]:
                    await self.handle_shorts_ad(st, last_url)
                else:
                    await self.shorts_diag(st)
                    await asyncio.sleep(random.uniform(*config.SHORTS_WATCH_SEC))
                last_url = st["url"]
            await self.next_short()

    async def shorts_diag(self, st):
        """광고 표시('스폰서' 등)가 화면에 있는데 감지를 못 했으면 원인 분석용으로 HTML 저장."""
        try:
            hint = await self.page.evaluate("""() => {
                const root = document.querySelector('ytd-shorts') || document.body;
                const t = root.innerText || '';
                const aria = [...root.querySelectorAll('[aria-label]')].map(e => e.getAttribute('aria-label')).join(' ');
                const m = (t + ' ' + aria).match(/스폰서|Sponsored|광고/);
                return m ? m[0] : ''; }""")
        except Exception:
            return
        if not hint:
            return
        d = config.DATA / "diag"
        d.mkdir(exist_ok=True)
        today = db.today()
        if len(list(d.glob(f"shorts_{today}_*.html"))) >= 15:
            return
        try:
            html = await self.page.evaluate("""() => { const r = document.querySelector('ytd-reel-video-renderer[is-active]')
                || document.querySelector('ytd-shorts'); return r ? r.outerHTML.slice(0, 400000) : ''; }""")
            name = d / f"shorts_{today}_{int(time.time())}.html"
            name.write_text(f"<!-- url={st.get('url')} hint={hint} -->\n" + html, encoding="utf-8")
            await self.shooter.shot(self.page, str(name.with_suffix(".jpg")), window=True)
            log.warning("쇼츠에 '%s' 표시가 있는데 광고로 감지 못 함 → %s 저장(분석용)", hint, name.name)
        except Exception as e:
            log.warning("쇼츠 진단 저장 실패: %s", e)

    async def next_short(self):
        before = self.page.url
        try:
            await self.page.keyboard.press("ArrowDown")
        except Exception:
            pass
        await asyncio.sleep(0.8)
        if self.page.url == before:  # 키 입력이 안 먹었으면 '다음' 버튼
            await self.click_first(["#navigation-button-down button",
                                    "button[aria-label*='다음 동영상']", "button[aria-label*='Next video']"])

    async def handle_shorts_ad(self, st, prev_url, js=None, placement="youtube_shorts", selectors=None, resume=None):
        js = js or SHORTS_STATE_JS
        selectors = selectors or SHORTS_CLICK_SELECTORS
        resume = resume or self.resume_shorts
        status.bump("ads_detected")
        vid = ""
        # 쇼츠 광고는 광고 영상 자체가 주소(/shorts/ID)로 열림 → 주소의 ID가 가장 확실
        m = re.search(r"/shorts/([A-Za-z0-9_-]{11})", st.get("url", ""))
        if m and st.get("url") != prev_url:
            vid = m.group(1)
        if st.get("data"):
            self.intel.ingest_text(st["data"])
            if not vid:
                m = re.search(r'"(?:externalVideoId|adVideoId)":"([A-Za-z0-9_-]{11})"', st["data"])
                if m:
                    vid = m.group(1)
        declared, click_url, hints = self.intel.lookup(vid)
        if not declared:
            from .adintel import declared_from_click
            for link in st.get("links", []):
                declared, click_url = declared_from_click(link), link
                break
        lines = clean_lines(st.get("text", "") + "\n" + "\n".join(l for l in st.get("labels", []) if l))
        debug = {"state": st}
        try:
            debug["reel"] = json.loads(await self.page.evaluate(DIAG_SHORTS_JS))
        except Exception as e:
            debug["reel_error"] = str(e)
        info = {
            "debug": debug,
            "placement": placement, "vid": vid, "declared": declared, "click_url": click_url,
            "lines": lines, "hints": hints, "vtitle": "", "vauthor": "", "dur": st.get("dur", 0),
            "context_url": st.get("url", ""), "context_title": f"쇼츠 피드 · {self.genre}",
        }
        start_url = st.get("url")

        async def get_state():
            s = await self.page.evaluate(js)
            alive = s.get("ok") and s.get("ad") and s.get("url") == start_url
            return alive, s.get("t", 0), s.get("dur", 0)

        log.info("쇼츠 광고 감지 · vid=%s 길이=%.1f 문구=%s 설정랜딩=%s", vid or "-", st.get("dur", 0),
                 " | ".join(lines[:6]), declared or "-")
        await self.process_ad(info, get_state, shot=self.shot_mshorts if self.mobile else self.shot_shorts,
                              click_selectors=selectors, resume=resume, click_last=True)

    def infeed_placement(self):
        return "youtube_mobile_infeed" if self.mobile else "youtube_infeed"

    async def scan_infeed(self, context_title):
        """페이지를 조금씩 내려 보며 인피드 광고 카드를 찾고, 새 광고면 캡처·1회 클릭."""
        if status.is_paused():
            return
        if config.INSTREAM_ONLY:
            return   # 추가 브라우저는 인스트림 전담
        if not self.mobile and random.random() > config.PC_INFEED_SCAN_RATE:
            return   # PC는 인스트림 우선: 인피드 확인은 가끔만
        placement = self.infeed_placement()
        status.update(action=f"{db.PLACEMENT_LABELS.get(placement)} 확인 중", placement=placement)
        found_any = False
        for step in range(6 if self.mobile else 2):
            try:
                ads = await self.page.evaluate(INFEED_SCAN_JS, self.mobile)
            except Exception:
                ads = []
            for ad in ads:
                found_any = True
                await self.handle_infeed_ad(ad, context_title)
            if self.mobile and getattr(self, "_m_cdp", None):
                try:   # 폰처럼 손가락으로 쓸어 올림(목록이 이어서 불러와짐)
                    sc = config.MOBILE_SCREEN
                    await self._m_cdp.send("Input.synthesizeScrollGesture", {
                        "x": sc["width"] // 2, "y": int(sc["height"] * 0.75), "yDistance": -int(sc["height"] * 0.55),
                        "speed": 1500, "gestureSourceType": "touch"})
                except Exception:
                    await self.page.evaluate("() => window.scrollBy(0, 600)")
            else:
                try:
                    await self.page.mouse.wheel(0, 700)
                except Exception:
                    await self.page.evaluate("() => window.scrollBy(0, 700)")
            await asyncio.sleep(1.0)
        try:
            await self.page.evaluate("() => window.scrollTo(0, 0)")
        except Exception:
            pass
        if not found_any:
            log.info("인피드 광고 없음 (%s)", placement)
            if self.mobile:
                await self.mobile_ad_diag("msearch")

    async def mobile_ad_diag(self, kind):
        """모바일에서 광고가 안 잡힐 때: 서버가 광고 데이터를 보냈는지 / 화면에 광고 표시가 있는지 기록(하루 8건)."""
        d = config.DATA / "diag"
        d.mkdir(exist_ok=True)
        today = db.today()
        if len(list(d.glob(f"{kind}_{today}_*.json"))) >= 8:
            return
        try:
            info = await self.page.evaluate("""() => {
                const out = {url: location.href};
                const cnt = (o, keys) => { const s = JSON.stringify(o || {}); const r = {};
                  keys.forEach(k => r[k] = (s.match(new RegExp('"' + k + '"', 'g')) || []).length); return r; };
                const keys = ['adPlacements', 'playerAds', 'adSlots', 'adSlotRenderer', 'inFeedAdLayoutRenderer',
                              'promotedSparklesWebRenderer', 'searchPyvRenderer', 'compactPromotedVideoRenderer', 'adBreakServiceRenderer'];
                try { out.initPR = cnt(window.ytInitialPlayerResponse, keys); } catch (e) {}
                try { out.initData = cnt(window.ytInitialData, keys); } catch (e) {}
                try { const p = document.querySelector('#movie_player, .html5-video-player');
                      out.livePR = cnt(p && p.getPlayerResponse && p.getPlayerResponse(), keys);
                      out.playerCls = p ? String(p.className).slice(0, 300) : ''; } catch (e) {}
                const hits = [];
                const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
                while (w.nextNode() && hits.length < 15) {
                  const t = w.currentNode.nodeValue.trim();
                  if (/^(스폰서|광고|Sponsored|Ad)$/.test(t) || /스폰서 ·|광고 ·/.test(t)) {
                    const chain = []; let e = w.currentNode.parentElement;
                    for (let i = 0; e && i < 8; i++, e = e.parentElement) chain.push(e.tagName.toLowerCase() + (e.className ? '.' + String(e.className).split(' ')[0] : ''));
                    hits.push({t, chain}); } }
                out.adTextHits = hits;
                out.adTags = [...new Set([...document.querySelectorAll('*')].map(e => e.tagName.toLowerCase())
                  .filter(t => /ad|promot|sponsor|pyv/.test(t) && t.includes('-')))].slice(0, 40);
                return out;
            }""")
            name = d / f"{kind}_{today}_{int(time.time())}"
            name.with_suffix(".json").write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding="utf-8")
            await self.page.screenshot(path=str(name.with_suffix(".jpg")), type="jpeg", quality=60)
        except Exception as e:
            log.warning("모바일 광고 진단 실패: %s", e)

    async def handle_infeed_ad(self, ad, context_title):
        import hashlib
        placement = self.infeed_placement()
        status.bump("ads_detected")
        lines = clean_lines(ad.get("text", "") + "\n" + "\n".join(l for l in ad.get("labels", []) if l))
        kp = "youtube_mobile" if self.mobile else PLATFORM
        sig = ad.get("vid") or hashlib.md5("|".join(lines[:4]).encode("utf-8")).hexdigest()[:16]
        ok = await self.page.evaluate(INFEED_FOCUS_JS, ad["id"])
        if not ok:
            return
        await asyncio.sleep(1.5)   # 화면 가운데로 옮긴 뒤 썸네일이 그려질 시간
        declared = ""
        from .adintel import declared_from_click
        for link in ad.get("links", []):
            if "adurl=" in link:
                declared = declared_from_click(link)
                break
        info = {
            "debug": {"infeed": ad}, "static": True, "key": f"{kp}:feed:{sig}",
            "placement": placement, "vid": ad.get("vid", ""), "declared": declared, "click_url": "",
            "lines": lines, "hints": [], "vtitle": "", "vauthor": "", "dur": 0,
            "context_url": self.page.url, "context_title": context_title,
        }
        log.info("%s 감지 · 문구=%s", db.PLACEMENT_LABELS.get(placement), " | ".join(lines[:5]))

        async def get_state():
            return True, 0, 0

        async def resume():
            await self.page.bring_to_front()

        await self.process_ad(info, get_state, shot=self.shot_viewport, click_selectors=MARKED_CTA,
                              resume=resume, click_last=True)
        self._static = False

    async def mobile_shorts_round(self):
        n = random.randint(*config.SHORTS_PER_ROUND)
        kw = random.choice(config.GENRES[self.genre])
        status.update(action=f"모바일 쇼츠 탐색 ({n}개)", placement="youtube_mobile_shorts", genre=self.genre)
        start_url = f"{config.YT_MOBILE_BASE}/shorts/"
        try:
            await self.goto(f"{config.YT_MOBILE_BASE}/results?search_query={quote(kw + ' #shorts')}")
            hrefs = await self.page.evaluate("() => [...document.querySelectorAll('a[href*=\"/shorts/\"]')].map(a=>a.href)")
            if hrefs:
                start_url = random.choice(hrefs[:10])
        except BotCheck:
            raise
        except Exception:
            pass
        log.info("모바일 쇼츠 라운드 · 장르=%s 검색어=%s → %s (%d개)", self.genre, kw, start_url, n)
        await self.goto(start_url)
        await asyncio.sleep(2)
        last_url, stuck = "", 0
        for i in range(n):
            if status.is_paused():
                return
            await asyncio.sleep(random.uniform(1.0, 1.8))
            st = await self.page.evaluate(MSHORTS_STATE_JS)
            status.bump("shorts")
            status.update(action=f"모바일 쇼츠 {i + 1}/{n} 시청 중", context_url=st.get("url", ""),
                          context_title=f"모바일 쇼츠 · {self.genre}", placement="youtube_mobile_shorts")
            if st.get("ad"):
                await self.handle_shorts_ad(st, last_url, js=MSHORTS_STATE_JS, placement="youtube_mobile_shorts",
                                            selectors=MARKED_CTA, resume=self.resume_mshorts)
            else:
                await self.shorts_diag(st)
                await asyncio.sleep(random.uniform(*config.SHORTS_WATCH_SEC))
            last_url = st.get("url", "")
            before = self.page.url
            await self.next_mshort()
            if self.page.url == before:
                stuck += 1
                if stuck >= 3:
                    status.event("모바일 쇼츠에서 다음 영상으로 넘어가지 못함 → 라운드 종료", "warn")
                    return
            else:
                stuck = 0

    async def next_mshort(self):
        """폰에서 위로 쓸어올리는 동작(터치 스와이프)으로 다음 쇼츠."""
        before = self.page.url
        sc = config.MOBILE_SCREEN
        try:
            await self._m_cdp.send("Input.synthesizeScrollGesture", {
                "x": sc["width"] // 2, "y": int(sc["height"] * 0.7), "yDistance": -int(sc["height"] * 0.6),
                "speed": 1800, "gestureSourceType": "touch"})
        except Exception:
            pass
        await asyncio.sleep(1.0)
        if self.page.url == before:
            try:
                await self.page.keyboard.press("ArrowDown")
            except Exception:
                pass
            await asyncio.sleep(0.8)

    async def resume_mshorts(self):
        await self.page.bring_to_front()
        await self.page.evaluate("""() => { const H = innerHeight; const v = [...document.querySelectorAll('video')]
            .find(v => { const r = v.getBoundingClientRect(); return r.top < H * 0.6 && r.bottom > H * 0.4; });
            if (v && v.paused) v.play().catch(() => {}); }""")

    async def resume_shorts(self):
        await self.page.bring_to_front()
        await self.page.evaluate("() => { const r=document.querySelector('ytd-reel-video-renderer[is-active]')||document;"
                                 " const v=r.querySelector('video'); if(v&&v.paused) v.play().catch(()=>{}); }")

    # ── 캡처 방식 ────────────────────────────────────
    async def shot_viewport(self, path):
        """게재보고 캡처: PC는 탭·주소창 포함 크롬 창 전체, 모바일은 폰 화면."""
        await self.shooter.shot(self.page, path, window=not self.mobile)

    async def shot_mshorts(self, path):
        await self.shooter.shot(self.page, path, window=False, hires=self.shooter.shorts_hires)

    async def shot_shorts(self, path):
        await self.shooter.shot(self.page, path, window=True)

    async def click_first(self, selectors):
        for sel in selectors:
            try:
                loc = self.page.locator(sel).first
                if await loc.count() and await loc.is_visible():
                    await loc.click(timeout=2500)
                    return True
            except Exception:
                continue
        return False

    # ── 광고 1건 처리: 중복 판정 → 8컷 → 1회 클릭 → 저장 ──────
    async def process_ad(self, info, get_state, shot, click_selectors, resume, click_last=False):
        placement = info["placement"]
        # 모바일 게재보고는 PC와 따로 남기도록 키를 분리
        kp = "youtube_mobile" if placement.startswith("youtube_mobile") else PLATFORM
        key = info.get("key") or (f"{kp}:{info['vid']}" if info["vid"] else "")
        existing = db.get_ad_by_key(self.conn, key) if key else None

        tmp_dir = config.DATA / "tmp"
        tmp_dir.mkdir(exist_ok=True)
        first_tmp = tmp_dir / f"first_{int(time.time() * 1000)}.jpg"
        first_t = None

        if not self.mobile:
            await self.close_extra_tabs()
        if not existing and not key:
            # ID가 없으면 화면 지문으로 판정 → 첫 컷을 먼저 찍음
            for _ in range(8):
                alive, t, _ = await get_state()
                if not alive:
                    break
                if t >= 0.8:
                    break
                await asyncio.sleep(0.3)
            await shot(str(first_tmp))
            first_t = (await get_state())[1]
            if is_mostly_blank(first_tmp):
                await asyncio.sleep(1.2)
                await shot(str(first_tmp))
                first_t = (await get_state())[1]
            dh = dhash(first_tmp)
            existing = db.find_similar_by_dhash(self.conn, PLATFORM, dh, config.DHASH_MAX_DISTANCE)
            key = f"{kp}:dh:{dh}"
            if not existing:
                existing = db.get_ad_by_key(self.conn, key)

        if config.AGENT and not existing:
            # 참여자 수집기: 중앙에 이미 있는 광고면 다시 찍지 않고 노출 기록만 보냄
            from . import agentlink
            if agentlink.known(key, locals().get("dh", "")):
                agentlink.sighting(key, placement, info.get("context_url", ""))
                status.bump("repeat_ads")
                status.update(action="이미 확보된 광고 · 노출 기록만 전송")
                first_tmp.unlink(missing_ok=True)
                return

        if existing and not self._needs_recapture(existing):
            db.add_sighting(self.conn, existing["id"], PLATFORM, placement, self.genre,
                            info["context_url"], info["context_title"])
            status.bump("repeat_ads")
            day_n = self.conn.execute("SELECT COUNT(*) FROM sightings WHERE ad_id=? AND day=?",
                                      (existing["id"], db.today())).fetchone()[0]
            status.update(action=f"이미 수집한 광고 · {existing['advertiser'] or existing['title'] or '광고'} (오늘 {day_n}회째)")
            status.event(f"재노출: {existing['advertiser'] or '-'} / {existing['title'][:30] if existing['title'] else '-'} (오늘 {day_n}회)")
            first_tmp.unlink(missing_ok=True)
            return

        if not self.mobile:
            await self.close_extra_tabs()
        # ── 새 광고 → 8컷 캡처 ──
        status.bump("new_ads")
        day = db.today()
        rel_dir = Path(day) / placement / _safe(key.split(":", 1)[1] if key else str(int(time.time())))
        out_dir = config.CAPTURES / rel_dir
        if out_dir.exists():
            rel_dir = Path(str(rel_dir) + f"_{int(time.time())}")
            out_dir = config.CAPTURES / rel_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        status.update(action=f"새 광고 감지! 캡처 시작 ({db.PLACEMENT_LABELS.get(placement, placement)})")
        status.event(f"새 광고 감지 · {placement}")

        frames = []  # (idx, t, relpath)
        self.live.hold = True
        try:
            if first_tmp.exists():
                p = out_dir / "01.jpg"
                shutil.move(str(first_tmp), p)
                frames.append((1, first_t or 0, (rel_dir / "01.jpg").as_posix()))
                await self.live.push(p)

            landing = {"url": "", "shot": ""}
            want_click = (config.CLICK_MODE == "always" or
                          (config.CLICK_MODE == "fallback" and not info["declared"]))

            async def do_click_once():
                if want_click and not landing.get("tried"):
                    landing["tried"] = True
                    u, s = await self.click_for_landing(click_selectors, out_dir, resume)
                    landing["url"], landing["shot"] = u, s

            # 가로형: 첫 컷 직후에 클릭(광고가 끝나면 버튼이 사라지므로)
            # 쇼츠: 광고가 반복 재생되므로 8컷을 다 찍은 뒤 클릭
            async def noop():
                pass
            first_hook = noop if click_last else do_click_once
            if frames:
                await first_hook()
            self._static = bool(info.get("static"))
            frames += await self.capture_frames(get_state, shot, out_dir, rel_dir, start_idx=len(frames) + 1,
                                                after_first=first_hook, already=len(frames))
            if not landing.get("tried"):
                await do_click_once()
        finally:
            self.live.hold = False

        if not frames:
            shutil.rmtree(out_dir, ignore_errors=True)
            return

        # 해시는 첫 '내용 있는' 컷 기준
        dh = ""
        for _, _, rp in frames:
            if not is_mostly_blank(config.CAPTURES / rp):
                dh = dhash(config.CAPTURES / rp)
                break
        if not key:
            key = f"{kp}:dh:{dh}"

        final_landing = landing.get("url", "")
        advertiser, title, cta = guess_fields(info["lines"], info["hints"], info["vtitle"], info["vauthor"],
                                              final_landing or info["declared"], is_ad_vid=bool(info["vid"]))
        raw = "\n".join(dict.fromkeys(
            [info["vtitle"], info["vauthor"], *info["lines"], *info["hints"], final_landing, info["declared"]]))
        fields = dict(
            platform=PLATFORM, placement=placement, advertiser=advertiser, title=title, cta=cta,
            ad_video_id=info["vid"], declared_url=info["declared"], landing_url=final_landing,
            raw_text=raw[:8000], ad_duration=float(info.get("dur") or 0), dhash=dh, frame_dir=rel_dir.as_posix(),
        )
        if existing:  # 재캡처
            ad_id = existing["id"]
            db.clear_frames(self.conn, ad_id)
            db.update_ad(self.conn, ad_id, captured_at=db.now_iso(), **fields)
        else:
            try:
                ad_id = db.create_ad(self.conn, ad_key=key, **fields)
            except Exception:  # 동시 중복 등
                row = db.get_ad_by_key(self.conn, key)
                if not row:
                    raise
                ad_id = row["id"]
        for idx, t, rp in frames:
            db.add_frame(self.conn, ad_id, idx, t, rp)
        if landing.get("shot"):
            db.add_frame(self.conn, ad_id, 99, 0, (rel_dir / "landing.jpg").as_posix(), kind="landing")
        db.add_sighting(self.conn, ad_id, PLATFORM, placement, self.genre, info["context_url"], info["context_title"])
        try:
            dbg = dict(info.get("debug") or {})
            dbg["intel_known_ids"] = list(self.intel.by_id)[-30:]
            dbg["intel_recent"] = [{"urls": sorted(r["urls"]), "texts": r["texts"]} for r in self.intel.recent]
            dbg["parsed"] = {"lines": info["lines"], "hints": info["hints"], "declared": info["declared"],
                             "vid": info["vid"], "advertiser": advertiser, "title": title, "cta": cta}
            import gzip   # 분석용 원본 데이터는 압축 저장(용량 1/10)
            with gzip.open(out_dir / "debug.json.gz", "wt", encoding="utf-8") as fz:
                fz.write(json.dumps(dbg, ensure_ascii=False, default=str))
        except Exception as e:
            log.warning("debug.json 저장 실패: %s", e)
        (out_dir / "meta.json").write_text(json.dumps(
            {**fields, "ad_key": key, "context_url": info["context_url"], "context_title": info["context_title"],
             "click_url": info["click_url"], "frames": [{"idx": i, "t": round(t, 2)} for i, t, _ in frames]},
            ensure_ascii=False, indent=2), encoding="utf-8")
        status.update(last_ad={"id": ad_id, "advertiser": advertiser, "title": title, "placement": placement,
                               "landing": final_landing or info["declared"], "thumb": frames[0][2],
                               "frames": len(frames), "at": db.now_iso()},
                      action=f"저장 완료 · {advertiser or '광고주 미상'} ({len(frames)}컷)")
        status.event(f"신규 저장: {advertiser or '-'} / {title[:40] or '-'} · {len(frames)}컷"
                     + (f" · 랜딩 {db.domain_of(final_landing or info['declared'])}" if (final_landing or info['declared']) else ""))

    def _needs_recapture(self, row):
        # 영상 광고인데 컷이 3장 이하로 저장된 경우(예: 쇼츠 재생 멈춤 문제 때 저장분) → 다시 만나면 8컷으로 다시 찍음
        try:
            if float(row["ad_duration"] or 0) > 5:
                n = self.conn.execute("SELECT COUNT(*) FROM frames WHERE ad_id=? AND kind!='landing'", (row["id"],)).fetchone()[0]
                if n <= 3:
                    return True
        except Exception:
            pass
        if not config.RECAPTURE_AFTER_DAYS:
            return False
        from datetime import datetime
        try:
            last = datetime.fromisoformat(row["last_seen"])
            return (datetime.now() - last).days >= config.RECAPTURE_AFTER_DAYS
        except Exception:
            return False

    async def capture_frames(self, get_state, shot, out_dir, rel_dir, start_idx, after_first, already):
        """광고 재생 시점 기준으로 나머지 컷을 고르게 찍음."""
        n_total = config.FRAMES_PER_AD
        frames = []
        idx = start_idx
        dur = 0
        alive, t = True, 0
        for _ in range(0 if getattr(self, "_static", False) else 20):  # 길이 정보 대기
            alive, t, dur = await get_state()
            if not alive or dur > 0:
                break
            await asyncio.sleep(0.25)
        if not alive:
            return frames
        if dur <= 0:
            # 영상이 아닌 이미지형 광고 → 1컷
            if already == 0:
                p = out_dir / f"{idx:02d}.jpg"
                await shot(str(p))
                frames.append((idx, 0, (rel_dir / p.name).as_posix()))
                await self.live.push(p)
                await after_first()
            return frames
        span = min(dur, config.MAX_AD_WATCH_SEC)
        end = min(config.FRAME_POINTS[-1] * span, max(dur - 0.4, 0.5))
        k = n_total - already
        planned = [max(0.5, f * span) for f in config.FRAME_POINTS][already:n_total]
        if planned and planned[0] < t + 0.3:
            # 감지가 늦어 앞 지점을 놓쳤으면 남은 구간에 고르게 다시 배치
            start = min(t + 0.3, end)
            planned = [start + (end - start) * i / max(k - 1, 1) for i in range(k)] if k > 1 else [start]
        targets = [min(p, end) for p in planned]
        last_t = t
        stall_since = time.time()
        deadline = time.time() + span + 45
        while targets and time.time() < deadline:
            alive, t, d = await get_state()
            if not alive:
                break
            if t + 1.5 < last_t:   # 다른 광고로 넘어감(또는 쇼츠 반복재생)
                if d and abs(d - dur) > 1:
                    break
            if t > last_t + 0.05:
                stall_since = time.time()
            elif time.time() - stall_since > 6:
                await (self.resume_longform() if "instream" in str(rel_dir) else self.resume_shorts())
                stall_since = time.time()
            last_t = t
            if t >= targets[0] - 0.15:
                p = out_dir / f"{idx:02d}.jpg"
                await shot(str(p))
                frames.append((idx, t, (rel_dir / p.name).as_posix()))
                status.update(action=f"새 광고 캡처 중 {idx}/{n_total}컷")
                await self.live.push(p)
                targets.pop(0)
                if idx == 1:
                    await after_first()
                idx += 1
                continue
            await asyncio.sleep(0.12)
        # 쇼츠 고해상도 캡처 안전장치: 영상 광고인데 컷이 3장 이하로 끝나는 일이 2번 연속이면 고해상도 끄기
        if self.mobile and "mobile_shorts" in str(rel_dir) and self.shooter.shorts_hires and dur > 8:
            if already + len(frames) <= 3:
                self.shooter.shorts_fail += 1
                if self.shooter.shorts_fail >= 2:
                    self.shooter.shorts_hires = False
                    status.event("쇼츠 고해상도 캡처 중 재생이 멈춰 일반 캡처로 전환", "warn")
            else:
                self.shooter.shorts_fail = 0
        return frames

    async def click_for_landing(self, selectors, out_dir, resume):
        """광고를 1회 클릭해 최종 랜딩 URL과 랜딩 페이지 화면을 저장."""
        page = self.page
        target = None
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if await loc.count() and await loc.is_visible():
                    target = loc
                    break
            except Exception:
                continue
        if not target:  # 표시는 됐는데 '보이지 않음'으로 판정된 버튼(애니메이션 중 등)은 강제로 1회 클릭
            for sel in selectors:
                try:
                    loc = page.locator(sel).first
                    if await loc.count():
                        await loc.scroll_into_view_if_needed(timeout=2000)
                        target = loc
                        break
                except Exception:
                    continue
        if not target:
            status.event("클릭할 광고 버튼을 찾지 못함(랜딩은 광고 데이터 기준으로 저장)", "warn")
            return "", ""
        before_url = page.url
        final, shot_path = "", ""
        status.update(action="랜딩 URL 확인을 위해 광고 1회 클릭")
        try:
            async with self.ctx.expect_page(timeout=8000) as pinfo:
                try:
                    await target.click(timeout=3000)
                except Exception:
                    await target.click(timeout=3000, force=True)
            newp = await pinfo.value
            final = await self._settle(newp)
            shot_path = str(out_dir / "landing.jpg")
            try:  # 랜딩도 주소창이 보이는 창 전체로(PC) 캡처 → 게재 증빙
                await self.shooter.shot(newp, shot_path, quality=85, window=not self.mobile)
            except Exception:
                shot_path = ""
            await newp.close()
        except Exception:
            # 새 탭이 안 열리고 같은 탭에서 이동한 경우
            await asyncio.sleep(2)
            if page.url != before_url and "youtube.com" not in (urlparse(page.url).hostname or ""):
                final = await self._settle(page)
                shot_path = str(out_dir / "landing.jpg")
                try:
                    await self.shooter.shot(page, shot_path, quality=85, window=not self.mobile)
                except Exception:
                    shot_path = ""
                await page.go_back(timeout=20000)
        for p in self.ctx.pages:
            if p is not page and p is not self.pc_page and p is not self.m_page:
                try:
                    await p.close()
                except Exception:
                    pass
        await resume()
        host = (urlparse(final).hostname or "") if final else ""
        if host.endswith("youtube.com") or host.endswith("google.com") and "/aclk" not in final:
            # 유튜브 안(채널·영상)이나 구글 로그인으로 간 경우는 광고주 랜딩이 아니므로 버림
            status.event(f"클릭 결과가 광고주 랜딩이 아님({host}) → 랜딩 미확인으로 저장", "warn")
            try:
                if shot_path:
                    Path(shot_path).unlink(missing_ok=True)
            except Exception:
                pass
            return "", ""
        if final:
            status.bump("clicks")
            status.event(f"랜딩 확인: {final[:120]}")
        return final, shot_path

    async def _settle(self, p):
        """리다이렉트(추적 URL)가 끝날 때까지 기다린 뒤 최종 URL 반환."""
        try:
            await p.wait_for_load_state("domcontentloaded", timeout=config.LANDING_TIMEOUT_SEC * 1000)
        except Exception:
            pass
        last, same = p.url, 0
        for _ in range(12):
            await asyncio.sleep(1)
            if p.url == last and p.url not in ("about:blank", ""):
                same += 1
                if same >= 2:
                    break
            else:
                last, same = p.url, 0
        try:
            await p.wait_for_load_state("load", timeout=8000)
        except Exception:
            pass
        return p.url

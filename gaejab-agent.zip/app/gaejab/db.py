"""SQLite 저장소 + 전문검색 색인.

ads        : 광고 1건 = 소재 1개 (처음 볼 때만 캡처)
frames     : 광고별 캡처 이미지 경로(8컷 + 랜딩 페이지)
sightings  : 노출 로그 (볼 때마다 1줄) → 일별 노출 횟수 리포트의 원천
ads_fts    : 광고주/제목/랜딩 도메인/화면 텍스트 검색 색인 (trigram → 한글 부분검색 가능)
"""
import sqlite3
from datetime import datetime, date as _date
from urllib.parse import urlparse

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS ads (
    id            INTEGER PRIMARY KEY,
    ad_key        TEXT UNIQUE NOT NULL,     -- 'youtube:<광고영상ID>' 또는 'youtube:dh:<이미지해시>'
    platform      TEXT NOT NULL,            -- youtube / naver / instagram
    placement     TEXT NOT NULL,            -- youtube_instream / youtube_shorts …
    advertiser    TEXT DEFAULT '',          -- 광고주/브랜드
    title         TEXT DEFAULT '',          -- 광고 제목
    cta           TEXT DEFAULT '',          -- 버튼 문구(자세히 알아보기 등)
    ad_video_id   TEXT DEFAULT '',
    declared_url  TEXT DEFAULT '',          -- 광고 데이터에 적힌 랜딩 URL
    landing_url   TEXT DEFAULT '',          -- 1회 클릭으로 확인한 최종 랜딩 URL
    landing_domain TEXT DEFAULT '',
    raw_text      TEXT DEFAULT '',          -- 광고 화면에서 읽은 모든 텍스트(검색용)
    ad_duration   REAL DEFAULT 0,
    dhash         TEXT DEFAULT '',
    frame_dir     TEXT DEFAULT '',          -- captures 아래 상대경로
    first_seen    TEXT NOT NULL,
    last_seen     TEXT NOT NULL,
    captured_at   TEXT NOT NULL,
    notes         TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_ads_platform ON ads(platform, placement);
CREATE INDEX IF NOT EXISTS ix_ads_dhash ON ads(platform, dhash);

CREATE TABLE IF NOT EXISTS frames (
    id      INTEGER PRIMARY KEY,
    ad_id   INTEGER NOT NULL REFERENCES ads(id),
    idx     INTEGER NOT NULL,      -- 1~8, 랜딩 페이지는 99
    t       REAL DEFAULT 0,        -- 광고 재생 시점(초)
    path    TEXT NOT NULL,         -- captures 아래 상대경로
    kind    TEXT DEFAULT 'frame'   -- frame / landing
);
CREATE INDEX IF NOT EXISTS ix_frames_ad ON frames(ad_id);

CREATE TABLE IF NOT EXISTS sightings (
    id            INTEGER PRIMARY KEY,
    ad_id         INTEGER NOT NULL REFERENCES ads(id),
    ts            TEXT NOT NULL,
    day           TEXT NOT NULL,
    platform      TEXT NOT NULL,
    placement     TEXT NOT NULL,
    genre         TEXT DEFAULT '',
    context_url   TEXT DEFAULT '',     -- 광고가 붙은 영상/페이지
    context_title TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_sight_day ON sightings(day, ad_id);

CREATE VIRTUAL TABLE IF NOT EXISTS ads_fts USING fts5(
    advertiser, title, landing_domain, raw_text, cta,
    content='ads', content_rowid='id', tokenize='trigram'
);
CREATE TRIGGER IF NOT EXISTS ads_ai AFTER INSERT ON ads BEGIN
  INSERT INTO ads_fts(rowid, advertiser, title, landing_domain, raw_text, cta)
  VALUES (new.id, new.advertiser, new.title, new.landing_domain, new.raw_text, new.cta);
END;
CREATE TRIGGER IF NOT EXISTS ads_ad AFTER DELETE ON ads BEGIN
  INSERT INTO ads_fts(ads_fts, rowid, advertiser, title, landing_domain, raw_text, cta)
  VALUES ('delete', old.id, old.advertiser, old.title, old.landing_domain, old.raw_text, old.cta);
END;
CREATE TRIGGER IF NOT EXISTS ads_au AFTER UPDATE ON ads BEGIN
  INSERT INTO ads_fts(ads_fts, rowid, advertiser, title, landing_domain, raw_text, cta)
  VALUES ('delete', old.id, old.advertiser, old.title, old.landing_domain, old.raw_text, old.cta);
  INSERT INTO ads_fts(rowid, advertiser, title, landing_domain, raw_text, cta)
  VALUES (new.id, new.advertiser, new.title, new.landing_domain, new.raw_text, new.cta);
END;
"""

PLACEMENT_LABELS = {
    "youtube_instream": "PC 인스트림",
    "youtube_infeed": "PC 인피드",
    "youtube_mobile_instream": "모바일 인스트림",
    "youtube_mobile_infeed": "모바일 인피드",
    "youtube_mobile_shorts": "모바일 쇼츠",
    "youtube_shorts": "PC 쇼츠(수집 제외)",
}


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def today():
    return _date.today().isoformat()


def domain_of(url):
    try:
        host = urlparse(url).hostname or ""
        return host[4:] if host.startswith("www.") else host
    except Exception:
        return ""


def connect():
    config.ensure_dirs()
    conn = sqlite3.connect(config.DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=30000")
    conn.executescript(SCHEMA)
    return conn


def migrate(conn):
    """예전 버전 데이터 보정: 윈도우 역슬래시 경로, 광고 문구 재해석."""
    conn.execute("UPDATE frames SET path=replace(path, char(92), '/') WHERE instr(path, char(92)) > 0")
    conn.execute("UPDATE ads SET frame_dir=replace(frame_dir, char(92), '/') WHERE instr(frame_dir, char(92)) > 0")
    # 해석 못 한 구글 클릭 URL이 '설정 랜딩'으로 잘못 들어간 경우 비움
    conn.execute("UPDATE ads SET declared_url='' WHERE declared_url LIKE '%/pagead/aclk%' AND declared_url NOT LIKE '%adurl=%'")
    from .adintel import clean_lines, guess_fields
    import json as _json
    for r in conn.execute("SELECT id, raw_text, landing_url, declared_url, frame_dir FROM ads "
                          "WHERE ad_video_id='' OR placement='youtube_shorts'").fetchall():
        # 광고 ID 없이 저장된 광고는 화면에서 읽은 문구(debug.json)만으로 다시 해석
        # (예전 버전은 다른 광고의 데이터가 섞여 들어갈 수 있었음)
        dbg = config.CAPTURES / (r["frame_dir"] or "") / "debug.json"
        lines = None
        try:
            if dbg.exists():
                txt = dbg.read_text(encoding="utf-8")
            else:
                import gzip
                with gzip.open(str(dbg) + ".gz", "rt", encoding="utf-8") as fz:
                    txt = fz.read()
            st = _json.loads(txt).get("state") or {}
            lines = clean_lines((st.get("adText") or st.get("text") or "") + "\n" + "\n".join(st.get("labels") or []))
        except Exception:
            pass
        if lines is None:
            lines = clean_lines("\n".join(l for l in (r["raw_text"] or "").split("\n") if not l.startswith("http")))
        adv, title, cta = guess_fields(lines, landing_url=r["landing_url"])
        raw = "\n".join(lines + ([r["landing_url"]] if r["landing_url"] else []))
        conn.execute("UPDATE ads SET advertiser=?, title=?, cta=?, raw_text=?, declared_url='' WHERE id=?",
                     (adv, title, cta, raw, r["id"]))
    conn.commit()


# ── 조회/저장 ─────────────────────────────────────────
def get_ad_by_key(conn, key):
    return conn.execute("SELECT * FROM ads WHERE ad_key=?", (key,)).fetchone()


def find_similar_by_dhash(conn, platform, dh, max_dist):
    if not dh:
        return None
    from .imaging import hamming
    best = None
    for row in conn.execute("SELECT id, dhash FROM ads WHERE platform=? AND dhash!=''", (platform,)):
        d = hamming(dh, row["dhash"])
        if d <= max_dist and (best is None or d < best[0]):
            best = (d, row["id"])
    if best:
        return conn.execute("SELECT * FROM ads WHERE id=?", (best[1],)).fetchone()
    return None


def create_ad(conn, **f):
    ts = now_iso()
    f.setdefault("first_seen", ts)
    f.setdefault("last_seen", ts)
    f.setdefault("captured_at", ts)
    if f.get("landing_url") or f.get("declared_url"):
        f["landing_domain"] = domain_of(f.get("landing_url") or f.get("declared_url"))
    cols = ",".join(f)
    q = ",".join("?" * len(f))
    cur = conn.execute(f"INSERT INTO ads ({cols}) VALUES ({q})", tuple(f.values()))
    conn.commit()
    return cur.lastrowid


def update_ad(conn, ad_id, **f):
    if not f:
        return
    if "landing_url" in f or "declared_url" in f:
        row = conn.execute("SELECT landing_url, declared_url FROM ads WHERE id=?", (ad_id,)).fetchone()
        lu = f.get("landing_url", row["landing_url"]) or f.get("declared_url", row["declared_url"])
        f["landing_domain"] = domain_of(lu)
    sets = ",".join(f"{k}=?" for k in f)
    conn.execute(f"UPDATE ads SET {sets} WHERE id=?", (*f.values(), ad_id))
    conn.commit()


def add_frame(conn, ad_id, idx, t, relpath, kind="frame"):
    conn.execute("INSERT INTO frames (ad_id, idx, t, path, kind) VALUES (?,?,?,?,?)",
                 (ad_id, idx, t, relpath, kind))
    conn.commit()


def add_sighting(conn, ad_id, platform, placement, genre="", context_url="", context_title=""):
    ts = now_iso()
    conn.execute(
        "INSERT INTO sightings (ad_id, ts, day, platform, placement, genre, context_url, context_title)"
        " VALUES (?,?,?,?,?,?,?,?)",
        (ad_id, ts, ts[:10], platform, placement, genre, context_url, context_title))
    conn.execute("UPDATE ads SET last_seen=? WHERE id=?", (ts, ad_id))
    conn.commit()


def clear_frames(conn, ad_id):
    conn.execute("DELETE FROM frames WHERE ad_id=?", (ad_id,))
    conn.commit()


# ── 대시보드/리포트용 ─────────────────────────────────
def _fts_query(q):
    q = q.strip().replace('"', " ")
    terms = [t for t in q.split() if t]
    if not terms or any(len(t) < 3 for t in terms):
        return None  # trigram은 3글자 이상 → 짧은 검색어는 LIKE로
    return " AND ".join(f'"{t}"' for t in terms)


def search_ads(conn, q="", day=None, placement=None, limit=60, offset=0):
    where, args = [], []
    if q:
        fq = _fts_query(q)
        if fq:
            where.append("a.id IN (SELECT rowid FROM ads_fts WHERE ads_fts MATCH ?)")
            args.append(fq)
        else:  # 2글자 검색어가 섞이면 단어별 부분일치(AND)
            for term in q.split():
                like = f"%{term}%"
                where.append("(a.advertiser LIKE ? OR a.title LIKE ? OR a.landing_domain LIKE ? OR a.raw_text LIKE ? OR a.cta LIKE ?)")
                args += [like] * 5
    if day:
        where.append("a.id IN (SELECT ad_id FROM sightings WHERE day=?)")
        args.append(day)
    if placement:
        where.append("a.placement=?")
        args.append(placement)
    w = ("WHERE " + " AND ".join(where)) if where else ""
    sql = f"""
      SELECT a.*,
        (SELECT path FROM frames f WHERE f.ad_id=a.id AND f.kind='frame' ORDER BY idx LIMIT 1) AS thumb,
        (SELECT COUNT(*) FROM sightings s WHERE s.ad_id=a.id) AS total_seen,
        (SELECT COUNT(*) FROM sightings s WHERE s.ad_id=a.id AND s.day=?) AS day_seen
      FROM ads a {w} ORDER BY a.last_seen DESC LIMIT ? OFFSET ?"""
    rows = conn.execute(sql, (day or today(), *args, limit, offset)).fetchall()
    total = conn.execute(f"SELECT COUNT(*) FROM ads a {w}", args).fetchone()[0]
    return [dict(r) for r in rows], total


def ad_detail(conn, ad_id):
    ad = conn.execute("SELECT * FROM ads WHERE id=?", (ad_id,)).fetchone()
    if not ad:
        return None
    frames = [dict(r) for r in conn.execute("SELECT * FROM frames WHERE ad_id=? ORDER BY idx", (ad_id,))]
    sights = [dict(r) for r in conn.execute(
        "SELECT * FROM sightings WHERE ad_id=? ORDER BY ts DESC LIMIT 200", (ad_id,))]
    daily = [dict(r) for r in conn.execute(
        "SELECT day, COUNT(*) n FROM sightings WHERE ad_id=? GROUP BY day ORDER BY day DESC", (ad_id,))]
    return {"ad": dict(ad), "frames": frames, "sightings": sights, "daily": daily}


def day_summary(conn, day):
    new_ads = conn.execute("SELECT COUNT(*) FROM ads WHERE substr(first_seen,1,10)=?", (day,)).fetchone()[0]
    sightings = conn.execute("SELECT COUNT(*) FROM sightings WHERE day=?", (day,)).fetchone()[0]
    distinct = conn.execute("SELECT COUNT(DISTINCT ad_id) FROM sightings WHERE day=?", (day,)).fetchone()[0]
    by_place = [dict(r) for r in conn.execute(
        "SELECT placement, COUNT(*) n, COUNT(DISTINCT ad_id) ads FROM sightings WHERE day=? GROUP BY placement",
        (day,))]
    return {"day": day, "new_ads": new_ads, "sightings": sightings, "distinct_ads": distinct,
            "by_placement": by_place}


def day_rows(conn, day):
    """일별 리포트: 그날 본 광고별 노출 횟수."""
    return [dict(r) for r in conn.execute("""
      SELECT a.id, a.placement, a.advertiser, a.title, a.landing_domain, a.landing_url, a.declared_url,
             a.first_seen, a.frame_dir, COUNT(s.id) AS seen,
             MIN(s.ts) AS first_ts, MAX(s.ts) AS last_ts,
             (substr(a.first_seen,1,10)=?) AS is_new,
             (SELECT path FROM frames f WHERE f.ad_id=a.id AND f.kind='frame' ORDER BY idx LIMIT 1) AS thumb
      FROM sightings s JOIN ads a ON a.id=s.ad_id
      WHERE s.day=? GROUP BY a.id ORDER BY seen DESC, a.advertiser""", (day, day))]


def all_days(conn):
    return [dict(r) for r in conn.execute(
        "SELECT day, COUNT(*) sightings, COUNT(DISTINCT ad_id) ads FROM sightings GROUP BY day ORDER BY day DESC")]

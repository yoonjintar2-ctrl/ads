"""윈도우 전용: 실제 크롬 창(탭·주소창 포함)을 통째로 캡처.

PrintWindow(PW_RENDERFULLCONTENT)를 써서 창이 화면 밖에 있거나 다른 창에 가려져 있어도 캡처됩니다.
윈도우가 아니거나 실패하면 available=False → 호출하는 쪽에서 페이지 캡처로 대체합니다.
"""
import os
import sys

AVAILABLE = sys.platform == "win32"
HIDE_TASKBAR = True

if AVAILABLE:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    try:
        dwmapi = ctypes.windll.dwmapi
    except Exception:
        dwmapi = None

    try:  # 화면 배율(125% 등)과 무관하게 실제 픽셀 기준으로
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass

    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
                    ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                    ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                    ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                    ("biClrImportant", wintypes.DWORD)]

    SWP_NOZORDER, SWP_NOACTIVATE = 0x0004, 0x0010
    HWND_BOTTOM = 1

    # 64비트에서 핸들이 잘리지 않도록 반환/인자 타입 지정
    _H = ctypes.c_void_p
    user32.GetWindowDC.restype = _H
    user32.GetWindowDC.argtypes = [wintypes.HWND]
    user32.ReleaseDC.argtypes = [wintypes.HWND, _H]
    user32.PrintWindow.argtypes = [wintypes.HWND, _H, wintypes.UINT]
    user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, wintypes.UINT]
    gdi32.CreateCompatibleDC.restype = _H
    gdi32.CreateCompatibleDC.argtypes = [_H]
    gdi32.CreateCompatibleBitmap.restype = _H
    gdi32.CreateCompatibleBitmap.argtypes = [_H, ctypes.c_int, ctypes.c_int]
    gdi32.SelectObject.restype = _H
    gdi32.SelectObject.argtypes = [_H, _H]
    gdi32.DeleteObject.argtypes = [_H]
    gdi32.DeleteDC.argtypes = [_H]
    gdi32.GetDIBits.argtypes = [_H, _H, wintypes.UINT, wintypes.UINT, ctypes.c_void_p, ctypes.c_void_p, wintypes.UINT]


def find_window(title_part):
    """제목에 title_part가 들어간 크롬 창 핸들."""
    if not AVAILABLE:
        return None
    found = []

    def cb(hwnd, _):
        n = user32.GetWindowTextLengthW(hwnd)
        if n:
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if title_part in buf.value:
                cls = ctypes.create_unicode_buffer(256)
                user32.GetClassNameW(hwnd, cls, 256)
                if cls.value.startswith("Chrome_WidgetWin"):
                    found.append(hwnd)
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    return found[0] if found else None


def is_window(hwnd):
    return bool(AVAILABLE and hwnd and user32.IsWindow(hwnd))


def offscreen_xy():
    """모든 모니터의 오른쪽 바깥 좌표."""
    vx, vw, vy = user32.GetSystemMetrics(76), user32.GetSystemMetrics(78), user32.GetSystemMetrics(77)
    return vx + vw + 200, vy


def on_screen(hwnd):
    """창이 어느 모니터에라도 걸쳐 보이면 True(모니터 연결·해상도 변경 때 윈도우가 창을 화면 안으로 끌고 옴)."""
    if not is_window(hwnd):
        return False
    user32.MonitorFromWindow.restype = ctypes.c_void_p
    user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
    return bool(user32.MonitorFromWindow(hwnd, 0))   # MONITOR_DEFAULTTONULL


GWL_EXSTYLE, WS_EX_TOOLWINDOW, WS_EX_APPWINDOW = -20, 0x00000080, 0x00040000


def in_taskbar(hwnd):
    st = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    return not (st & WS_EX_TOOLWINDOW)


def hide_from_taskbar(hwnd):
    """작업표시줄·Alt+Tab에서 수집용 크롬 창을 숨김(창 자체는 살아 있어 캡처 가능)."""
    try:
        st = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
        if st & WS_EX_TOOLWINDOW:
            return
        user32.ShowWindow(hwnd, 0)   # SW_HIDE → 스타일 반영
        user32.SetWindowLongW(hwnd, GWL_EXSTYLE, (st | WS_EX_TOOLWINDOW) & ~WS_EX_APPWINDOW)
        user32.ShowWindow(hwnd, 4)   # SW_SHOWNOACTIVATE
    except Exception:
        pass


LAST_PLACE = {"t": 0.0}


def no_animation(hwnd):
    """창 나타남/사라짐 애니메이션 끄기 — 애니메이션(반투명) 중에 찍히면 뒤쪽 화면이 비쳐 보이는 캡처가 나옴."""
    try:
        if dwmapi is not None:
            v = ctypes.c_int(1)
            dwmapi.DwmSetWindowAttribute(wintypes.HWND(hwnd), 3, ctypes.byref(v), ctypes.sizeof(v))  # DWMWA_TRANSITIONS_FORCEDISABLED
    except Exception:
        pass


def place(hwnd, mode, size):
    """창 위치/크기 지정. offscreen = 모든 모니터의 오른쪽 바깥 + 작업표시줄에서도 숨김."""
    if not is_window(hwnd):
        return
    import time as _t
    LAST_PLACE["t"] = _t.time()
    no_animation(hwnd)
    w, h = size
    if mode == "offscreen":
        x, y = offscreen_xy()
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE (최소화 상태면 캡처가 안 되므로)
        user32.SetWindowPos(hwnd, HWND_BOTTOM, x, y, w, h, SWP_NOACTIVATE)
        if HIDE_TASKBAR:
            hide_from_taskbar(hwnd)
    else:
        user32.ShowWindow(hwnd, 9)
        user32.SetWindowPos(hwnd, 0, 40, 40, w, h, SWP_NOZORDER | SWP_NOACTIVATE)


def _visible_rect(hwnd):
    rect = wintypes.RECT()
    if dwmapi is not None:
        # 윈도우10/11의 보이지 않는 테두리를 뺀 실제 창 영역
        if dwmapi.DwmGetWindowAttribute(hwnd, 9, ctypes.byref(rect), ctypes.sizeof(rect)) == 0:
            return rect
    user32.GetWindowRect(hwnd, ctypes.byref(rect))
    return rect


def capture(hwnd, path, quality=88):
    """창 전체를 JPEG로 저장. 성공하면 True."""
    if not is_window(hwnd):
        return False
    from PIL import Image
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 4)  # SW_SHOWNOACTIVATE
    full = wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(full))
    vis = _visible_rect(hwnd)
    w, h = full.right - full.left, full.bottom - full.top
    if w <= 0 or h <= 0:
        return False
    hdc_win = user32.GetWindowDC(hwnd)
    hdc_mem = gdi32.CreateCompatibleDC(hdc_win)
    bmp = gdi32.CreateCompatibleBitmap(hdc_win, w, h)
    old = gdi32.SelectObject(hdc_mem, bmp)
    try:
        ok = user32.PrintWindow(hwnd, hdc_mem, 2)  # PW_RENDERFULLCONTENT
        if not ok:
            return False
        bih = BITMAPINFOHEADER()
        bih.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        bih.biWidth, bih.biHeight = w, -h
        bih.biPlanes, bih.biBitCount, bih.biCompression = 1, 32, 0
        buf = ctypes.create_string_buffer(w * h * 4)
        if not gdi32.GetDIBits(hdc_mem, bmp, 0, h, buf, ctypes.byref(bih), 0):
            return False
        img = Image.frombuffer("RGB", (w, h), buf, "raw", "BGRX", 0, 1)
        # 보이지 않는 테두리 잘라내기
        l, t = vis.left - full.left, vis.top - full.top
        r, b = l + (vis.right - vis.left), t + (vis.bottom - vis.top)
        if 0 <= l < r <= w and 0 <= t < b <= h:
            img = img.crop((l, t, r, b))
        tmp = str(path) + ".tmp.jpg"
        img.save(tmp, "JPEG", quality=quality)
        os.replace(tmp, path)
        return True
    finally:
        gdi32.SelectObject(hdc_mem, old)
        gdi32.DeleteObject(bmp)
        gdi32.DeleteDC(hdc_mem)
        user32.ReleaseDC(hwnd, hdc_win)

"""일별 리포트 — 그날 본 광고별 노출 횟수 (HTML + CSV)."""
import csv
import html

from . import config, db


def write_day(conn, day):
    rows = db.day_rows(conn, day)
    summ = db.day_summary(conn, day)
    config.REPORTS.mkdir(parents=True, exist_ok=True)

    csv_path = config.REPORTS / f"{day}.csv"
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:   # 엑셀에서 한글 깨짐 방지
        w = csv.writer(f)
        w.writerow(["날짜", "지면", "광고주/브랜드", "광고 제목", "노출 횟수", "신규 여부", "랜딩 도메인",
                    "랜딩 URL", "첫 노출", "마지막 노출", "캡처 폴더"])
        for r in rows:
            w.writerow([day, db.PLACEMENT_LABELS.get(r["placement"], r["placement"]), r["advertiser"], r["title"],
                        r["seen"], "신규" if r["is_new"] else "", r["landing_domain"],
                        r["landing_url"] or r["declared_url"], r["first_ts"][11:16], r["last_ts"][11:16],
                        r["frame_dir"]])

    def esc(s):
        return html.escape(str(s or ""))

    def tr(r):
        img = '<img src="../captures/%s">' % esc(r["thumb"]) if r["thumb"] else ""
        new = ' <span class=new>NEW</span>' if r["is_new"] else ""
        return ("<tr><td>%s</td><td>%s</td><td><b>%s</b>%s<br>%s</td><td class=n>%s</td><td>%s</td><td>%s~%s</td></tr>"
                % (img, esc(db.PLACEMENT_LABELS.get(r["placement"], r["placement"])), esc(r["advertiser"]), new,
                   esc(r["title"]), r["seen"], esc(r["landing_domain"]), esc(r["first_ts"][11:16]),
                   esc(r["last_ts"][11:16])))

    trs = "".join(tr(r) for r in rows)
    place = " · ".join(f"{esc(db.PLACEMENT_LABELS.get(p['placement'], p['placement']))} {p['ads']}개/{p['n']}회"
                       for p in summ["by_placement"])
    page = f"""<!doctype html><html lang=ko><meta charset=utf-8><title>게잡머신 {day}</title>
<style>body{{font:14px/1.5 -apple-system,'Apple SD Gothic Neo','Malgun Gothic',sans-serif;margin:24px;color:#111}}
table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #ddd;padding:6px 8px;text-align:left;vertical-align:middle}}
img{{width:160px;border-radius:4px}}.n{{font-weight:700;font-size:18px;text-align:right}}
.new{{background:#e11d48;color:#fff;font-size:11px;padding:1px 5px;border-radius:3px}}</style>
<h1>게잡머신 일별 리포트 · {day}</h1>
<p>노출된 광고 {summ['distinct_ads']}개 · 총 노출 {summ['sightings']}회 · 신규 {summ['new_ads']}개<br>{place}</p>
<table><tr><th>캡처</th><th>지면</th><th>광고주 / 제목</th><th>노출</th><th>랜딩</th><th>시간대</th></tr>{trs}</table>"""
    (config.REPORTS / f"{day}.html").write_text(page, encoding="utf-8")
    return csv_path

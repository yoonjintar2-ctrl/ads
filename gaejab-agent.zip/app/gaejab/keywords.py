"""검색어 성과 관리 + 자동 확장.

- 수집기가 검색어를 쓸 때마다 사용 횟수, 그 검색어로 들어간 영상에서 새 광고가 나오면 '새 광고' 횟수를 기록
- 다음 검색어를 고를 때 새 광고가 잘 나온 검색어에 가중치(처음 쓰는 검색어도 몇 번은 꼭 시도)
- 중앙 PC가 하루 한 번: 성과 좋은 검색어로 유튜브 자동완성을 받아 새 검색어를 추가, 오래 써도 성과 없는 추가 검색어는 쉬게 함
- 장르 균형은 그대로(장르는 한 바퀴씩 고르게 돌고, 장르 '안에서' 검색어만 최적화)
"""
import json
import logging
import random
import re
import threading
import time
import urllib.parse
import urllib.request

from . import config, db

log = logging.getLogger("gaejab")
SCHEMA = """CREATE TABLE IF NOT EXISTS kw_stats (
    kw TEXT PRIMARY KEY, genre TEXT, src TEXT DEFAULT 'base', uses INTEGER DEFAULT 0, new_ads INTEGER DEFAULT 0,
    seen INTEGER DEFAULT 0, added TEXT, last_used TEXT, off INTEGER DEFAULT 0)"""
REPORT = config.DATA / "keyword_report.json"


def _ensure(conn):
    conn.execute(SCHEMA)


def pick(conn, genre, base_list):
    """장르 안에서 다음 검색어 고르기(성과 가중 + 탐색)."""
    try:
        _ensure(conn)
        rows = {r[0]: r for r in conn.execute("SELECT kw, uses, new_ads, off, src FROM kw_stats WHERE genre=?", (genre,))}
    except Exception:
        return random.choice(base_list)
    cands = list(dict.fromkeys(list(base_list) + [k for k, r in rows.items() if r[4] != "base" and not r[3]]))
    weights = []
    for k in cands:
        r = rows.get(k)
        uses, new = (r[1], r[2]) if r else (0, 0)
        w = (new + 1.0) / (uses + 3.0)
        if uses < 3:
            w = max(w, 0.5)          # 새 검색어는 최소 몇 번은 시도
        if r and r[3]:
            w *= 0.15                 # 쉬는 중인 기본 검색어도 가끔은
        weights.append(w)
    return random.choices(cands, weights=weights, k=1)[0]


def used(conn, kw, genre):
    try:
        _ensure(conn)
        conn.execute("INSERT INTO kw_stats (kw, genre, src, added) VALUES (?,?, 'base', ?) ON CONFLICT(kw) DO NOTHING",
                     (kw, genre, db.now_iso()))
        conn.execute("UPDATE kw_stats SET uses=uses+1, last_used=? WHERE kw=?", (db.now_iso(), kw))
        conn.commit()
    except Exception:
        pass


def hit(conn, kw, new=True):
    if not kw:
        return
    try:
        _ensure(conn)
        conn.execute(f"UPDATE kw_stats SET {'new_ads' if new else 'seen'}={'new_ads' if new else 'seen'}+1 WHERE kw=?", (kw,))
        conn.commit()
    except Exception:
        pass


# ── 중앙 PC: 하루 한 번 확장·정리 ─────────────────────
def suggest(q):
    url = ("https://suggestqueries-clients6.youtube.com/complete/search?client=youtube&ds=yt&hl=ko&gl=kr&q="
           + urllib.parse.quote(q))
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            txt = r.read().decode("utf-8", "ignore")
        m = re.search(r"\((\[.*\])\)\s*$", txt, re.S)
        data = json.loads(m.group(1) if m else txt)
        return [x[0] for x in data[1] if isinstance(x, list) and x and isinstance(x[0], str)]
    except Exception:
        return []


def optimize(conn, per_genre=3):
    _ensure(conn)
    added, rested = [], []
    for genre, base in config.GENRES.items():
        rows = conn.execute("SELECT kw, uses, new_ads, src, off FROM kw_stats WHERE genre=?", (genre,)).fetchall()
        known = {r[0] for r in rows} | set(base)
        # 성과 좋은 검색어(사용 3회 이상) 상위 2개 → 자동완성으로 새 검색어
        good = sorted([r for r in rows if r[1] >= 3 and not r[4]], key=lambda r: -(r[2] + 1) / (r[1] + 3))[:2]
        seeds = [r[0] for r in good] or random.sample(list(base), min(2, len(base)))
        n = 0
        for sd in seeds:
            for s in suggest(sd):
                s = s.strip()
                if n >= per_genre:
                    break
                if s in known or len(s) < 2 or len(s) > 30:
                    continue
                conn.execute("INSERT OR IGNORE INTO kw_stats (kw, genre, src, added) VALUES (?,?, 'suggest', ?)",
                             (s, genre, db.now_iso()))
                known.add(s)
                added.append((genre, s))
                n += 1
            time.sleep(1)
        # 12번 넘게 써도 새 광고 0인 추가 검색어는 쉬게 함(기본 검색어는 가중치로만 조절)
        for r in rows:
            if r[3] != "base" and not r[4] and r[1] >= 12 and r[2] == 0:
                conn.execute("UPDATE kw_stats SET off=1 WHERE kw=?", (r[0],))
                rested.append((genre, r[0]))
    conn.commit()
    rep = {"at": db.now_iso(), "added": added, "rested": rested, "genres": {}}
    for genre in config.GENRES:
        rs = conn.execute("SELECT kw, src, uses, new_ads, off FROM kw_stats WHERE genre=? ORDER BY "
                          "(new_ads+1.0)/(uses+3.0) DESC", (genre,)).fetchall()
        rep["genres"][genre] = [{"kw": r[0], "src": r[1], "uses": r[2], "new": r[3], "off": r[4]} for r in rs]
    REPORT.write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    log.info("검색어 최적화: 새 검색어 %d개 추가, %d개 쉬게 함", len(added), len(rested))
    return rep


def _loop():
    time.sleep(600)
    while True:
        try:
            last = json.loads(REPORT.read_text(encoding="utf-8")).get("at", "") if REPORT.exists() else ""
        except Exception:
            last = ""
        if last[:10] != db.today():
            conn = db.connect()
            try:
                optimize(conn)
            except Exception as e:
                log.warning("검색어 최적화 오류: %s", e)
            finally:
                conn.close()
        time.sleep(3600)


def start():
    threading.Thread(target=_loop, daemon=True, name="keywords").start()

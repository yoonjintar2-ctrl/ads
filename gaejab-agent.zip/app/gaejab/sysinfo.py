"""PC 사양·부하 측정 → data/sysinfo.json (멀티 브라우저 운용 가능 여부 판단용). 윈도우 전용."""
import ctypes
import json
import logging
import os
import shutil
import subprocess
import threading
import time

from . import config

log = logging.getLogger("gaejab")
OUT = config.DATA / "sysinfo.json"
NOWIN = 0x08000000  # CREATE_NO_WINDOW


def _ps(cmd, timeout=40):
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True,
                           timeout=timeout, creationflags=NOWIN)
        for enc in ("utf-8", "mbcs"):
            try:
                return r.stdout.decode(enc).strip()
            except Exception:
                pass
    except Exception as e:
        return f"ERR {e}"
    return ""


class MEMSTAT(ctypes.Structure):
    _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def _mem():
    m = MEMSTAT()
    m.dwLength = ctypes.sizeof(MEMSTAT)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
    return {"total_gb": round(m.ullTotalPhys / 2**30, 1), "avail_gb": round(m.ullAvailPhys / 2**30, 1),
            "load_pct": m.dwMemoryLoad}


def _cpu_load(sec=5.0):
    FT = ctypes.c_ulonglong
    def times():
        i, k, u = FT(), FT(), FT()
        ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(i), ctypes.byref(k), ctypes.byref(u))
        return i.value, k.value, u.value
    a = times(); time.sleep(sec); b = times()
    idle, tot = b[0] - a[0], (b[1] - a[1]) + (b[2] - a[2])
    return round(100 * (1 - idle / tot), 1) if tot else None


def collect():
    info = {"at": time.strftime("%Y-%m-%d %H:%M:%S"), "cores_logical": os.cpu_count()}
    info["cpu"] = _ps("(Get-CimInstance Win32_Processor | Select-Object -First 1 Name,NumberOfCores,MaxClockSpeed | ConvertTo-Json -Compress)")
    info["gpu"] = _ps("(Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM | ConvertTo-Json -Compress)")
    info["os"] = _ps("(Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version | ConvertTo-Json -Compress)")
    info["mem"] = _mem()
    info["cpu_load_samples"] = [_cpu_load(5) for _ in range(6)]   # 30초 동안 5초 간격
    try:
        du = shutil.disk_usage(str(config.DATA))
        info["disk_free_gb"] = round(du.free / 2**30, 1)
    except Exception:
        pass
    # 수집용 크롬(전용 프로필)과 전체 크롬이 쓰는 메모리·CPU
    info["chrome"] = _ps(
        "$all=Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\";"
        "$mine=$all | Where-Object { $_.CommandLine -like '*chrome_profile_youtube*' };"
        "$py=Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' };"
        "[pscustomobject]@{all_n=$all.Count; all_mb=[math]::Round((($all|Measure-Object WorkingSetSize -Sum).Sum)/1MB);"
        "gaejab_n=$mine.Count; gaejab_mb=[math]::Round((($mine|Measure-Object WorkingSetSize -Sum).Sum)/1MB);"
        "python_mb=[math]::Round((($py|Measure-Object WorkingSetSize -Sum).Sum)/1MB)} | ConvertTo-Json -Compress")
    info["python_procs"] = _ps("Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' } | "
                               "Select-Object ProcessId,@{n='mb';e={[math]::Round($_.WorkingSetSize/1MB)}},"
                               "@{n='cmd';e={($_.CommandLine -replace '.*run.py','run.py')}} | ConvertTo-Json -Compress")
    info["top_cpu"] = _ps("Get-Process | Sort-Object CPU -Descending | Select-Object -First 8 Name,"
                          "@{n='mb';e={[math]::Round($_.WorkingSet64/1MB)}} | ConvertTo-Json -Compress")
    return info


def _loop():
    while True:
        try:
            OUT.write_text(json.dumps(collect(), ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            log.exception("사양 측정 실패")
        time.sleep(600)


def start():
    if os.name != "nt":
        return
    threading.Thread(target=_loop, daemon=True, name="sysinfo").start()

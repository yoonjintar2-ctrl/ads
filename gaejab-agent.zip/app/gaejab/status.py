"""진행 상황(status.json)과 일시정지 신호(control.json)."""
import json
import logging
import os
import threading
from collections import deque

from . import config
from .db import now_iso

_lock = threading.Lock()
_state = {
    "state": "starting",         # starting / running / paused / waiting / bot_check / error / stopped
    "action": "준비 중",
    "platform": "", "placement": "", "genre": "",
    "context_url": "", "context_title": "",
    "started_at": now_iso(), "updated_at": now_iso(),
    "session": {"videos": 0, "shorts": 0, "ads_detected": 0, "new_ads": 0, "repeat_ads": 0, "clicks": 0},
    "last_ad": None,
    "warnings": [],
}
_events = deque(maxlen=60)


def update(**kw):
    with _lock:
        _state.update(kw)
        _state["updated_at"] = now_iso()
        _flush()


def bump(key, n=1):
    with _lock:
        _state["session"][key] = _state["session"].get(key, 0) + n
        _flush()


def event(msg, level="info"):
    # 대시보드 진행 기록과 같은 내용을 로그 파일(gaejab.log)에도 남김
    logging.getLogger("gaejab").log({"warn": logging.WARNING, "error": logging.ERROR}.get(level, logging.INFO), msg)
    with _lock:
        _events.appendleft({"ts": now_iso(), "msg": msg, "level": level})
        if level in ("warn", "error"):
            _state["warnings"] = ([{"ts": now_iso(), "msg": msg}] + _state["warnings"])[:10]
        _flush()


def _flush():
    data = dict(_state)
    data["events"] = list(_events)
    tmp = str(config.STATUS_PATH) + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, config.STATUS_PATH)
    except Exception:
        pass


def read():
    try:
        with open(config.STATUS_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"state": "stopped", "action": "수집기가 실행 중이 아닙니다"}


def read_control():
    try:
        with open(config.CONTROL_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def write_control(**kw):
    """control.json: paused(일시정지), want_running(수집 켜짐 유지), stop(종료 요청)."""
    with _lock:
        d = read_control()
        d.update(kw)
        d["at"] = now_iso()
        tmp = str(config.CONTROL_PATH) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False)
        os.replace(tmp, config.CONTROL_PATH)


def set_paused(paused: bool):
    write_control(paused=paused)


def is_paused():
    c = read_control()
    return bool(c.get("paused") or c.get("auto_paused"))   # auto_paused: 참여자 PC가 바빠서 잠시 쉬는 중


def stop_requested():
    """전체 종료 요청, 또는 이 수집기 역할만 끄라는 요청(메모리가 부족해 브라우저 수를 줄일 때)."""
    c = read_control()
    return bool(c.get("stop")) or (config.ROLE and config.ROLE in (c.get("stop_roles") or []))

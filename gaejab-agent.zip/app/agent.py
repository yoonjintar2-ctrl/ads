"""게재나라 참여 프로그램 (참여자 컴퓨터용).

- 내 컴퓨터의 남는 힘으로 유튜브 광고 게재면을 찾아 게재나라 서버로 보내고, 새 광고로 확인되면 포인트를 받습니다.
- 평소 쓰는 크롬과 완전히 분리된 '수집 전용 크롬'만 사용합니다(내 로그인·북마크·파일에 접근하지 않음).
- 이 창(제어 화면): http://localhost:8766  — 시작 / 일시정지 / 중지 / 로그인 / 포인트 확인
"""
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)   # 설치 폴더(%LOCALAPPDATA%\\GaejaeNara)
os.environ["GAEJAB_AGENT"] = "1"
os.environ.setdefault("GAEJAB_DATA", os.path.join(ROOT, "data"))
os.environ.setdefault("GAEJAB_PORT", "8766")
sys.path.insert(0, BASE)

import json  # noqa: E402
import logging  # noqa: E402
import logging.handlers  # noqa: E402
import threading  # noqa: E402
import time  # noqa: E402
import webbrowser  # noqa: E402
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer  # noqa: E402

from gaejab import agentlink, config, status  # noqa: E402
from gaejab.supervisor import Supervisor, free_gb  # noqa: E402

VERSION = "1.1.0"
PORT = 8766
log = logging.getLogger("gaejab")


def setup_logging():
    config.ensure_dirs()
    h = logging.handlers.RotatingFileHandler(config.DATA / "agent.log", maxBytes=2_000_000, backupCount=2, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.setLevel(logging.INFO)
    log.addHandler(h)


def find_chrome():
    cands = [os.path.join(os.environ.get(k, ""), "Google", "Chrome", "Application", "chrome.exe")
             for k in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")]
    return next((c for c in cands if c and os.path.exists(c)), "")


def syscheck():
    """참여 가능한 컴퓨터인지 확인."""
    res = {"ok": True, "items": []}

    def add(name, ok, msg, block=False):
        res["items"].append({"name": name, "ok": ok, "msg": msg})
        if not ok and block:
            res["ok"] = False
    win = sys.platform == "win32"
    add("운영체제", win, "윈도우 10/11" if win else "지금은 윈도우만 지원해요", block=True)
    total = avail = 0
    try:
        from gaejab.sysinfo import _mem
        m = _mem()
        total, avail = m["total_gb"], m["avail_gb"]
    except Exception:
        pass
    if total:
        add("메모리", total >= 6, f"총 {total:.0f}GB · 지금 여유 {avail:.1f}GB" +
            ("" if total >= 6 else " — 6GB 이상 권장(4GB 미만은 참여 불가)"), block=total < 4)
    chrome = find_chrome()
    add("구글 크롬", bool(chrome), "설치돼 있어요" if chrome else "구글 크롬을 먼저 설치해 주세요", block=True)
    cores = os.cpu_count() or 0
    add("CPU", cores >= 4, f"{cores}코어" + ("" if cores >= 4 else " — 4코어 이상 권장"))
    return res


SUP = None
_me = {"at": 0, "data": None}


def me(force=False):
    if not agentlink.token():
        return None
    if force or time.time() - _me["at"] > 60:
        j = agentlink.call("POST", "/api/agent/hello", {"version": VERSION})
        _me["data"] = j.get("me") if j.get("ok") else None
        _me["at"] = time.time()
        if j.get("status") == 401:
            agentlink.TOKEN_FILE.unlink(missing_ok=True)
    return _me["data"]


PAGE = open(os.path.join(BASE, "agent_ui.html"), encoding="utf-8").read() if os.path.exists(os.path.join(BASE, "agent_ui.html")) else "<h1>게재나라 참여</h1>"


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        b = body if isinstance(body, bytes) else (json.dumps(body, ensure_ascii=False).encode() if not isinstance(body, str) else body.encode())
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            return self._send(200, PAGE, "text/html; charset=utf-8")
        if self.path.startswith("/api/state"):
            st = status.read()
            ctl = status.read_control()
            info = SUP.info() if SUP else {}
            return self._send(200, {
                "version": VERSION, "logged_in": bool(agentlink.token()), "me": me(),
                "running": info.get("running"), "browsers": info.get("browsers_alive"), "free_gb": free_gb(),
                "paused": bool(ctl.get("paused")), "auto_paused": bool(ctl.get("auto_paused")), "want_running": bool(ctl.get("want_running")),
                "action": st.get("action", ""), "session": st.get("session", {}), "upload": agentlink.STATS,
                "check": CHECK})
        return self._send(404, {})

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n).decode() or "{}")
        except Exception:
            body = {}
        if self.path == "/api/login":
            j = agentlink.login(str(body.get("id", "")).strip().lower(), str(body.get("pw", "")))
            _me["at"] = 0
            return self._send(200, {"ok": bool(j.get("ok")), "error": j.get("error", "")})
        if self.path == "/api/logout":
            SUP.stop("로그아웃")
            agentlink.logout()
            return self._send(200, {"ok": True})
        if self.path == "/api/control":
            a = body.get("action")
            if a == "start":
                if not CHECK["ok"]:
                    return self._send(200, {"ok": False, "error": "이 컴퓨터는 참여 조건에 맞지 않아요"})
                if not agentlink.token():
                    return self._send(200, {"ok": False, "error": "먼저 로그인해 주세요"})
                status.write_control(paused=False)
                threading.Thread(target=SUP.start, args=("시작 버튼",), daemon=True).start()
            elif a == "pause":
                status.write_control(paused=True)
            elif a == "resume":
                status.write_control(paused=False)
            elif a == "stop":
                threading.Thread(target=SUP.stop, args=("중지 버튼",), daemon=True).start()
            elif a == "quit":
                def bye():
                    SUP.stop("프로그램 종료")
                    agentlink.beat("off", force=True)
                    os._exit(0)
                threading.Thread(target=bye, daemon=True).start()
            return self._send(200, {"ok": True})
        return self._send(404, {})


CHECK = {"ok": True, "items": []}


def main():
    global SUP, CHECK
    setup_logging()
    # 이미 켜져 있으면 제어 화면만 열기
    try:
        import urllib.request
        urllib.request.urlopen(f"http://localhost:{PORT}/api/state", timeout=2).read()
        webbrowser.open(f"http://localhost:{PORT}")
        return
    except Exception:
        pass
    CHECK = syscheck()
    log.info("참여 프로그램 시작 v%s · 점검 %s", VERSION, CHECK)
    SUP = Supervisor()
    status.write_control(want_running=False, stop=False, stop_roles=[])   # 켜자마자 수집하지 않음(시작 버튼으로)
    SUP.watch()
    agentlink.start()
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)   # 내 컴퓨터 안에서만 열림(외부 접속 불가)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    if "--no-open" not in sys.argv:
        webbrowser.open(f"http://localhost:{PORT}")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        SUP.stop("종료")


if __name__ == "__main__":
    main()

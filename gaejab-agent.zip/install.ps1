﻿# 게재나라 참여 프로그램 설치 스크립트 (누구나 열어서 내용을 확인할 수 있어요)
# - 관리자 권한 없이 내 사용자 폴더(AppData\Local\GaejaeNara)에만 설치해요.
# - 파이썬(python.org 공식 배포본)과 필요한 부품(pypi.org 공식 저장소)을 내려받아요.
# - 평소 쓰는 크롬은 건드리지 않고, 수집 전용 크롬 데이터는 위 폴더 안에 따로 만들어요.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$Root = Join-Path $env:LOCALAPPDATA 'GaejaeNara'
$Py = Join-Path $Root 'python'
$PyUrl = 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-embed-amd64.zip'
$PipUrl = 'https://bootstrap.pypa.io/get-pip.py'

function Say($t) { Write-Host "  $t" }
function Fail($t) { Write-Host ""; Write-Host "  [설치 중단] $t" -ForegroundColor Red; Write-Host ""; Read-Host "  Enter를 누르면 창이 닫혀요"; exit 1 }

Write-Host ""
Write-Host "  ===== 게재나라 참여 프로그램 설치 =====" -ForegroundColor Cyan
Write-Host ""

# 1) 참여 가능한 컴퓨터인지 확인
if ([Environment]::OSVersion.Version.Major -lt 10) { Fail "윈도우 10 이상에서만 설치할 수 있어요." }
if (-not [Environment]::Is64BitOperatingSystem) { Fail "64비트 윈도우에서만 설치할 수 있어요." }
$ram = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 1)
if ($ram -lt 4) { Fail "메모리가 $ram GB라 참여가 어려워요(4GB 이상 필요, 6GB 이상 권장)." }
$chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $chrome) { Start-Process "https://www.google.com/chrome/"; Fail "구글 크롬이 필요해요. 방금 연 페이지에서 크롬을 설치한 뒤 다시 실행해 주세요." }
Say "점검 통과 · 메모리 $ram GB · 크롬 확인"

# 2) 이미 켜져 있는 참여 프로그램은 잠시 끄기
Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($Root, 'OrdinalIgnoreCase') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

New-Item -ItemType Directory -Force -Path $Root | Out-Null
$tmp = Join-Path $Root 'tmp'; New-Item -ItemType Directory -Force -Path $tmp | Out-Null
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# 3) 파이썬(공식 배포본) 준비
if (-not (Test-Path "$Py\python.exe")) {
  Say "파이썬 내려받는 중(python.org, 약 11MB)…"
  Invoke-WebRequest $PyUrl -OutFile "$tmp\python.zip" -UseBasicParsing
  Expand-Archive "$tmp\python.zip" -DestinationPath $Py -Force
  $pth = Get-ChildItem $Py -Filter 'python*._pth' | Select-Object -First 1
  (Get-Content $pth.FullName) -replace '^#\s*import site', 'import site' | Set-Content $pth.FullName -Encoding ASCII
}
if (-not (Test-Path "$Py\Scripts\pip.exe")) {
  Say "설치 도구(pip) 준비 중…"
  Invoke-WebRequest $PipUrl -OutFile "$tmp\get-pip.py" -UseBasicParsing
  & "$Py\python.exe" "$tmp\get-pip.py" --no-warn-script-location -q
  if ($LASTEXITCODE -ne 0) { Fail "pip 설치에 실패했어요. 인터넷 연결을 확인해 주세요." }
}
Say "필요한 부품 설치 중(pypi.org, 약 50MB · 1~3분)…"
& "$Py\python.exe" -m pip install -q --no-warn-script-location --upgrade "playwright==1.48.0" "pillow>=10.4"
if ($LASTEXITCODE -ne 0) { Fail "부품 설치에 실패했어요. 인터넷 연결을 확인해 주세요." }

# 4) 프로그램 파일 복사
if (Test-Path "$Root\app") { Remove-Item "$Root\app" -Recurse -Force }
Copy-Item (Join-Path $PSScriptRoot 'app') "$Root\app" -Recurse -Force
Copy-Item (Join-Path $PSScriptRoot 'uninstall.ps1') "$Root\uninstall.ps1" -Force
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

# 5) 시작 메뉴 바로가기(참여 / 삭제)
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) '게재나라'
New-Item -ItemType Directory -Force -Path $menu | Out-Null
$sh = New-Object -ComObject WScript.Shell
$l = $sh.CreateShortcut("$menu\게재나라 참여.lnk"); $l.TargetPath = "$Py\pythonw.exe"; $l.Arguments = "`"$Root\app\agent.py`""; $l.WorkingDirectory = "$Root\app"; $l.Description = '게재나라 참여 프로그램'; $l.Save()
$u = $sh.CreateShortcut("$menu\게재나라 참여 삭제.lnk"); $u.TargetPath = "powershell.exe"; $u.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$Root\uninstall.ps1`""; $u.Description = '게재나라 참여 프로그램 삭제'; $u.Save()

Say "설치 완료! 참여 화면을 열게요."
Start-Process "$Py\pythonw.exe" -ArgumentList "`"$Root\app\agent.py`"" -WorkingDirectory "$Root\app"
Write-Host ""
Say "앞으로는 시작 메뉴 > 게재나라 > '게재나라 참여'로 켜고, '게재나라 참여 삭제'로 지울 수 있어요."
Write-Host ""
Start-Sleep -Seconds 4

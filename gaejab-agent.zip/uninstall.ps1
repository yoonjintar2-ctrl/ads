﻿# 게재나라 참여 프로그램 삭제 스크립트
# - 설치 폴더(AppData\Local\GaejaeNara)와 시작 메뉴 바로가기만 지워요. 평소 쓰는 크롬과 다른 파일은 건드리지 않아요.
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$Root = Join-Path $env:LOCALAPPDATA 'GaejaeNara'
Write-Host ""
Write-Host "  ===== 게재나라 참여 프로그램 삭제 =====" -ForegroundColor Cyan
$ans = Read-Host "  정말 지울까요? 수집 전용 크롬 데이터도 함께 지워져요 (Y/N)"
if ($ans -notmatch '^[Yy]') { exit 0 }
# 참여 프로그램과 수집 전용 크롬만 종료(설치 폴더 안에서 실행 중인 것만)
Get-CimInstance Win32_Process | Where-Object {
  ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($Root, 'OrdinalIgnoreCase')) -or ($_.CommandLine -and $_.CommandLine -like "*$Root*")
} | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 2
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) '게재나라'
Remove-Item $menu -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $Root -Recurse -Force -ErrorAction SilentlyContinue
if (Test-Path $Root) { Write-Host "  일부 파일이 사용 중이라 남았어요. 컴퓨터를 다시 켠 뒤 이 폴더를 지워 주세요: $Root" -ForegroundColor Yellow }
else { Write-Host "  모두 지웠어요. 참여해 주셔서 고마워요!" -ForegroundColor Green }
Start-Sleep -Seconds 4
